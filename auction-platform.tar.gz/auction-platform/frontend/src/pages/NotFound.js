// NotFound.js
import React from 'react';
import { Link } from 'react-router-dom';

export default function NotFound() {
  return (
    <div style={{ minHeight: '100vh', display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', textAlign: 'center', padding: 24 }}>
      <div style={{ fontFamily: 'var(--font-display)', fontSize: 'clamp(80px, 20vw, 180px)', color: 'rgba(245,158,11,0.15)', lineHeight: 1 }}>404</div>
      <h1 style={{ fontSize: 32, fontWeight: 700, marginTop: -20, marginBottom: 12 }}>Page Not Found</h1>
      <p style={{ color: 'var(--text-secondary)', marginBottom: 32, maxWidth: 400 }}>The page you're looking for doesn't exist or has been moved.</p>
      <Link to="/" className="btn btn-primary btn-lg">← Back to Home</Link>
    </div>
  );
}
