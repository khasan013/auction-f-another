import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { loadStripe } from '@stripe/stripe-js';
import { Elements, CardElement, useStripe, useElements } from '@stripe/react-stripe-js';
import { auctionAPI, paymentAPI } from '../services/api';
import toast from 'react-hot-toast';

const stripePromise = loadStripe(process.env.REACT_APP_STRIPE_PUBLISHABLE_KEY || 'pk_test_placeholder');

const CARD_ELEMENT_OPTIONS = {
  style: {
    base: {
      fontSize: '16px', color: '#f5f5f5', '::placeholder': { color: '#606060' },
      fontFamily: '"DM Sans", sans-serif',
    },
    invalid: { color: '#ef4444' },
  },
};

function CheckoutForm({ auction, clientSecret, onSuccess }) {
  const stripe = useStripe();
  const elements = useElements();
  const [loading, setLoading] = useState(false);
  const [address, setAddress] = useState({ name: '', street: '', city: '', state: '', zipCode: '', country: 'US' });

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!stripe || !elements) return;
    setLoading(true);
    try {
      const { paymentIntent, error } = await stripe.confirmCardPayment(clientSecret, {
        payment_method: { card: elements.getElement(CardElement), billing_details: { name: address.name } },
      });
      if (error) { toast.error(error.message); return; }
      if (paymentIntent.status === 'succeeded') {
        await paymentAPI.confirm(auction._id, { paymentIntentId: paymentIntent.id, shippingAddress: address });
        toast.success('🎉 Payment successful! You own this item!');
        onSuccess();
      }
    } catch (err) { toast.error(err.message); }
    finally { setLoading(false); }
  };

  return (
    <form onSubmit={handleSubmit} style={{ display: 'flex', flexDirection: 'column', gap: 20 }}>
      <h3 style={{ fontSize: 16, fontWeight: 700 }}>Shipping Address</h3>
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 16 }}>
        {[['Full Name', 'name', '1 / -1'], ['Street Address', 'street', '1 / -1'], ['City', 'city', ''], ['State', 'state', ''], ['ZIP Code', 'zipCode', ''], ['Country', 'country', '']].map(([label, key, gridColumn]) => (
          <div key={key} className="form-group" style={gridColumn ? { gridColumn } : {}}>
            <label className="form-label">{label}</label>
            <input className="form-input" value={address[key]} onChange={e => setAddress(p => ({ ...p, [key]: e.target.value }))} required />
          </div>
        ))}
      </div>

      <div>
        <h3 style={{ fontSize: 16, fontWeight: 700, marginBottom: 12 }}>Payment Details</h3>
        <div style={{ padding: '14px', background: 'var(--bg-elevated)', border: '1px solid var(--border)', borderRadius: 10 }}>
          <CardElement options={CARD_ELEMENT_OPTIONS} />
        </div>
        <p style={{ fontSize: 12, color: 'var(--text-muted)', marginTop: 8 }}>🔒 Secured by Stripe. Test: 4242 4242 4242 4242</p>
      </div>

      <button type="submit" className="btn btn-primary btn-lg" disabled={!stripe || loading} style={{ width: '100%' }}>
        {loading ? 'Processing payment…' : `Pay $${((auction?.currentPrice || 0) + (auction?.shipping?.isFree ? 0 : auction?.shipping?.cost || 0)).toFixed(2)}`}
      </button>
    </form>
  );
}

export default function CheckoutPage() {
  const { auctionId } = useParams();
  const navigate = useNavigate();
  const [auction, setAuction] = useState(null);
  const [clientSecret, setClientSecret] = useState('');
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const load = async () => {
      try {
        const [auctionRes, intentRes] = await Promise.all([
          auctionAPI.getOne(auctionId),
          paymentAPI.createIntent(auctionId),
        ]);
        setAuction(auctionRes.auction);
        setClientSecret(intentRes.clientSecret);
      } catch (err) {
        toast.error(err.message || 'Failed to load checkout');
        navigate('/dashboard');
      } finally { setLoading(false); }
    };
    load();
  }, [auctionId]);

  if (loading) return <div className="page" style={{ display: 'flex', justifyContent: 'center', paddingTop: 120 }}><div className="spinner" /></div>;

  return (
    <div className="page">
      <div className="container" style={{ maxWidth: 900, paddingTop: 40, paddingBottom: 64 }}>
        <h1 style={{ fontSize: 28, fontWeight: 700, marginBottom: 32 }}>Complete Purchase</h1>
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 380px', gap: 32, alignItems: 'start' }}>
          <div style={{ background: 'var(--bg-surface)', border: '1px solid var(--border)', borderRadius: 20, padding: 32 }}>
            <Elements stripe={stripePromise} options={{ clientSecret }}>
              <CheckoutForm auction={auction} clientSecret={clientSecret} onSuccess={() => navigate('/dashboard?tab=bids')} />
            </Elements>
          </div>

          {/* Order summary */}
          <div style={{ background: 'var(--bg-surface)', border: '1px solid var(--border)', borderRadius: 20, padding: 24, position: 'sticky', top: 88 }}>
            <h3 style={{ fontWeight: 700, marginBottom: 20 }}>Order Summary</h3>
            {auction?.images?.[0]?.url && <img src={auction.images[0].url} alt="" style={{ width: '100%', height: 200, objectFit: 'cover', borderRadius: 12, marginBottom: 16 }} />}
            <div style={{ fontWeight: 600, marginBottom: 16 }}>{auction?.title}</div>
            {[
              ['Winning Bid', `$${auction?.currentPrice?.toFixed(2)}`],
              ['Shipping', auction?.shipping?.isFree ? 'FREE' : `$${(auction?.shipping?.cost || 0).toFixed(2)}`],
              ['Platform Fee', 'Included'],
            ].map(([label, val]) => (
              <div key={label} style={{ display: 'flex', justifyContent: 'space-between', fontSize: 14, padding: '8px 0', borderBottom: '1px solid var(--border)' }}>
                <span style={{ color: 'var(--text-secondary)' }}>{label}</span>
                <span style={{ fontWeight: 600, color: val === 'FREE' ? 'var(--success)' : 'var(--text-primary)' }}>{val}</span>
              </div>
            ))}
            <div style={{ display: 'flex', justifyContent: 'space-between', marginTop: 12, fontWeight: 700, fontSize: 18 }}>
              <span>Total</span>
              <span style={{ color: 'var(--gold)', fontFamily: 'var(--font-mono)' }}>
                ${((auction?.currentPrice || 0) + (auction?.shipping?.isFree ? 0 : auction?.shipping?.cost || 0)).toFixed(2)}
              </span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
