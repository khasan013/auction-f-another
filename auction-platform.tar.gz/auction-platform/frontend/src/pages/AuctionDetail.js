import React, { useState, useEffect } from 'react';
import { useParams, Link } from 'react-router-dom';
import { auctionAPI, bidAPI } from '../services/api';
import { useAuth } from '../context/AuthContext';
import BidPanel from '../components/auction/BidPanel';
import { formatDistanceToNow, format } from 'date-fns';
import toast from 'react-hot-toast';

export default function AuctionDetail() {
  const { id } = useParams();
  const { user } = useAuth();
  const [auction, setAuction] = useState(null);
  const [isWatching, setIsWatching] = useState(false);
  const [bids, setBids] = useState([]);
  const [activeImage, setActiveImage] = useState(0);
  const [loading, setLoading] = useState(true);
  const [activeTab, setActiveTab] = useState('description');

  useEffect(() => {
    const load = async () => {
      setLoading(true);
      try {
        const [auctionRes, bidsRes] = await Promise.all([
          auctionAPI.getOne(id),
          bidAPI.getForAuction(id, { limit: 20 }),
        ]);
        setAuction(auctionRes.auction);
        setIsWatching(auctionRes.isWatching);
        setBids(bidsRes.bids || []);
      } catch {
        toast.error('Failed to load auction');
      } finally {
        setLoading(false);
      }
    };
    load();
  }, [id]);

  const handleWatch = async () => {
    if (!user) { toast.error('Please log in to watch auctions'); return; }
    try {
      const res = await auctionAPI.toggleWatch(id);
      setIsWatching(res.isWatching);
      toast.success(res.message);
    } catch {}
  };

  if (loading) return (
    <div className="page" style={{ display: 'flex', justifyContent: 'center', paddingTop: 120 }}>
      <div className="spinner" />
    </div>
  );
  if (!auction) return (
    <div className="page" style={{ textAlign: 'center', paddingTop: 120 }}>
      <div style={{ fontSize: 64, marginBottom: 16 }}>😕</div>
      <h2>Auction not found</h2>
      <Link to="/auctions" className="btn btn-primary" style={{ marginTop: 20, display: 'inline-flex' }}>Browse Auctions</Link>
    </div>
  );

  const images = auction.images || [];
  const primaryIdx = images.findIndex(i => i.isPrimary) || 0;

  return (
    <div className="page">
      <div className="container" style={{ paddingTop: 32, paddingBottom: 64 }}>
        {/* Breadcrumb */}
        <div style={{ fontSize: 13, color: 'var(--text-muted)', marginBottom: 24, display: 'flex', gap: 8, alignItems: 'center' }}>
          <Link to="/" style={{ color: 'var(--text-muted)' }}>Home</Link> /
          <Link to="/auctions" style={{ color: 'var(--text-muted)' }}>Auctions</Link> /
          <Link to={`/auctions?category=${auction.category}`} style={{ color: 'var(--text-muted)' }}>{auction.category}</Link> /
          <span style={{ color: 'var(--text-secondary)' }}>{auction.title.slice(0, 40)}…</span>
        </div>

        <div style={{ display: 'grid', gridTemplateColumns: '1fr 400px', gap: 40, alignItems: 'start' }}>
          {/* Left: Images + details */}
          <div>
            {/* Main image */}
            <div style={{ position: 'relative', borderRadius: 16, overflow: 'hidden', background: 'var(--bg-elevated)', marginBottom: 12 }}>
              {images[activeImage]?.url ? (
                <img src={images[activeImage].url} alt={auction.title} style={{ width: '100%', maxHeight: 520, objectFit: 'contain', display: 'block' }} />
              ) : (
                <div style={{ height: 400, display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 80, color: 'var(--text-muted)' }}>🖼️</div>
              )}
              {auction.isFeatured && (
                <div style={{ position: 'absolute', top: 16, left: 16, background: 'var(--gold)', color: '#000', padding: '4px 12px', borderRadius: 6, fontWeight: 700, fontSize: 13 }}>⭐ FEATURED</div>
              )}
            </div>

            {/* Thumbnails */}
            {images.length > 1 && (
              <div style={{ display: 'flex', gap: 8, overflowX: 'auto', paddingBottom: 4 }}>
                {images.map((img, i) => (
                  <button key={i} onClick={() => setActiveImage(i)} style={{
                    width: 72, height: 72, borderRadius: 8, overflow: 'hidden', flexShrink: 0, padding: 0,
                    border: `2px solid ${i === activeImage ? 'var(--gold)' : 'var(--border)'}`, cursor: 'pointer',
                  }}>
                    <img src={img.url} alt="" style={{ width: '100%', height: '100%', objectFit: 'cover' }} />
                  </button>
                ))}
              </div>
            )}

            {/* Title + meta */}
            <div style={{ marginTop: 28 }}>
              <div style={{ display: 'flex', gap: 10, flexWrap: 'wrap', marginBottom: 12 }}>
                <span className="badge" style={{ background: 'rgba(245,158,11,0.1)', color: 'var(--gold)', border: '1px solid var(--border-gold)' }}>{auction.category}</span>
                <span className="badge" style={{ background: 'var(--bg-elevated)', color: 'var(--text-secondary)', border: '1px solid var(--border)' }}>{auction.condition}</span>
                <span className={`badge badge-${auction.status}`}>{auction.status.charAt(0).toUpperCase() + auction.status.slice(1)}</span>
              </div>
              <h1 style={{ fontSize: 28, fontWeight: 700, lineHeight: 1.3, marginBottom: 16 }}>{auction.title}</h1>

              <div style={{ display: 'flex', gap: 20, marginBottom: 24, flexWrap: 'wrap' }}>
                <div style={{ display: 'flex', alignItems: 'center', gap: 8, fontSize: 14, color: 'var(--text-secondary)' }}>
                  <span>👁️ {auction.viewCount} views</span>
                </div>
                <div style={{ fontSize: 14, color: 'var(--text-secondary)' }}>
                  Listed {formatDistanceToNow(new Date(auction.createdAt), { addSuffix: true })}
                </div>
                {auction.seller && (
                  <Link to={`/users/${auction.seller._id}/profile`} style={{ display: 'flex', alignItems: 'center', gap: 8, fontSize: 14, color: 'var(--text-secondary)' }}>
                    {auction.seller.avatar?.url
                      ? <img src={auction.seller.avatar.url} alt="" style={{ width: 24, height: 24, borderRadius: '50%', objectFit: 'cover' }} />
                      : <div style={{ width: 24, height: 24, borderRadius: '50%', background: 'var(--gold)', fontSize: 11, fontWeight: 700, color: '#000', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>{auction.seller.name?.[0]}</div>
                    }
                    <span>by <b>{auction.seller.name}</b></span>
                    {auction.seller.sellerRating > 0 && <span style={{ color: 'var(--gold)' }}>⭐ {auction.seller.sellerRating.toFixed(1)}</span>}
                  </Link>
                )}
                <button onClick={handleWatch} style={{
                  background: isWatching ? 'rgba(245,158,11,0.1)' : 'var(--bg-elevated)',
                  border: `1px solid ${isWatching ? 'var(--gold)' : 'var(--border)'}`,
                  borderRadius: 8, padding: '4px 14px', fontSize: 13, color: isWatching ? 'var(--gold)' : 'var(--text-secondary)', cursor: 'pointer',
                }}>
                  {isWatching ? '👁️ Watching' : '+ Watch'}
                </button>
              </div>

              {/* Tabs */}
              <div style={{ display: 'flex', gap: 0, borderBottom: '1px solid var(--border)', marginBottom: 24 }}>
                {[['description', 'Description'], ['shipping', 'Shipping'], ['bids', `Bid History (${bids.length})`]].map(([key, label]) => (
                  <button key={key} onClick={() => setActiveTab(key)} style={{
                    padding: '10px 20px', background: 'none', fontSize: 14, fontWeight: 600,
                    color: activeTab === key ? 'var(--gold)' : 'var(--text-muted)',
                    borderBottom: `2px solid ${activeTab === key ? 'var(--gold)' : 'transparent'}`,
                    marginBottom: -1, transition: 'color 0.15s',
                  }}>{label}</button>
                ))}
              </div>

              {activeTab === 'description' && (
                <div style={{ color: 'var(--text-secondary)', lineHeight: 1.8, fontSize: 15, whiteSpace: 'pre-wrap' }}>
                  {auction.description}
                  {auction.tags?.length > 0 && (
                    <div style={{ marginTop: 20, display: 'flex', gap: 8, flexWrap: 'wrap' }}>
                      {auction.tags.map(tag => (
                        <span key={tag} style={{ padding: '3px 10px', background: 'var(--bg-elevated)', border: '1px solid var(--border)', borderRadius: 100, fontSize: 12, color: 'var(--text-muted)' }}>#{tag}</span>
                      ))}
                    </div>
                  )}
                </div>
              )}

              {activeTab === 'shipping' && (
                <div style={{ display: 'grid', gap: 12 }}>
                  {[
                    ['Shipping Cost', auction.shipping?.isFree ? 'FREE' : `$${auction.shipping?.cost?.toFixed(2) || '0.00'}`],
                    ['Ships From', auction.shipping?.location || 'Not specified'],
                    ['Handling Time', `${auction.shipping?.handlingTime || 3} business days`],
                    ['International', auction.shipping?.international ? 'Available' : 'Not available'],
                  ].map(([label, value]) => (
                    <div key={label} style={{ display: 'flex', justifyContent: 'space-between', padding: '12px 0', borderBottom: '1px solid var(--border)' }}>
                      <span style={{ color: 'var(--text-muted)' }}>{label}</span>
                      <span style={{ fontWeight: 600, color: value === 'FREE' ? 'var(--success)' : 'var(--text-primary)' }}>{value}</span>
                    </div>
                  ))}
                </div>
              )}

              {activeTab === 'bids' && (
                <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
                  {bids.length === 0 ? (
                    <p style={{ color: 'var(--text-muted)', textAlign: 'center', padding: 40 }}>No bids yet. Be the first!</p>
                  ) : bids.map((bid, i) => (
                    <div key={bid._id} style={{
                      display: 'flex', justifyContent: 'space-between', alignItems: 'center',
                      padding: '12px 16px', background: i === 0 ? 'rgba(245,158,11,0.05)' : 'var(--bg-elevated)',
                      border: `1px solid ${i === 0 ? 'var(--border-gold)' : 'var(--border)'}`, borderRadius: 10,
                    }}>
                      <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
                        {i === 0 && <span style={{ fontSize: 18 }}>🏆</span>}
                        <div>
                          <div style={{ fontWeight: 600, fontSize: 14 }}>{bid.bidder?.name || 'Anonymous'}</div>
                          <div style={{ fontSize: 12, color: 'var(--text-muted)' }}>{formatDistanceToNow(new Date(bid.createdAt), { addSuffix: true })}</div>
                        </div>
                      </div>
                      <div style={{ fontFamily: 'var(--font-mono)', fontWeight: 700, fontSize: 18, color: i === 0 ? 'var(--gold)' : 'var(--text-primary)' }}>
                        ${bid.amount.toFixed(2)}
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>

          {/* Right: Bid panel */}
          <div style={{ position: 'sticky', top: 88 }}>
            <BidPanel auction={auction} onUpdate={(data) => {
              setAuction(prev => ({ ...prev, currentPrice: data.newCurrentPrice, totalBids: data.totalBids, endTime: data.endTime }));
              setBids(prev => [data.bid, ...prev]);
            }} />
          </div>
        </div>
      </div>

      <style>{`@media (max-width: 900px) { .auction-grid { grid-template-columns: 1fr !important; } }`}</style>
    </div>
  );
}
