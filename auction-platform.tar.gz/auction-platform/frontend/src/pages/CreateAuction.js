import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { auctionAPI } from '../services/api';
import ImageUploader from '../components/auction/ImageUploader';
import toast from 'react-hot-toast';

const CATEGORIES = ['Electronics','Fashion','Collectibles','Art','Jewelry','Vehicles','Home & Garden','Sports','Toys','Books','Music','Gaming','Health & Beauty','Business','Other'];
const CONDITIONS = ['New','Like New','Very Good','Good','Acceptable'];

const defaultForm = {
  title: '', description: '', category: '', condition: '',
  startingPrice: '', reservePrice: '', buyNowPrice: '', minimumBidIncrement: '1',
  startTime: '', endTime: '',
  shipping: { isFree: false, cost: '', methods: [], handlingTime: '3', location: '', international: false },
  tags: '',
  autoExtend: { enabled: true, minutes: '5' },
};

export default function CreateAuction() {
  const navigate = useNavigate();
  const [form, setForm] = useState(defaultForm);
  const [images, setImages] = useState([]);
  const [loading, setLoading] = useState(false);
  const [step, setStep] = useState(1);

  const set = (key, val) => setForm(p => ({ ...p, [key]: val }));
  const setShipping = (key, val) => setForm(p => ({ ...p, shipping: { ...p.shipping, [key]: val } }));

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (images.length === 0) { toast.error('Please add at least one image'); return; }
    setLoading(true);
    try {
      const payload = {
        ...form,
        images,
        startingPrice: parseFloat(form.startingPrice),
        reservePrice: form.reservePrice ? parseFloat(form.reservePrice) : null,
        buyNowPrice: form.buyNowPrice ? parseFloat(form.buyNowPrice) : null,
        minimumBidIncrement: parseFloat(form.minimumBidIncrement),
        tags: form.tags.split(',').map(t => t.trim()).filter(Boolean),
        shipping: { ...form.shipping, cost: parseFloat(form.shipping.cost) || 0, handlingTime: parseInt(form.shipping.handlingTime) },
        autoExtend: { ...form.autoExtend, minutes: parseInt(form.autoExtend.minutes) },
      };
      const res = await auctionAPI.create(payload);
      toast.success('Auction created successfully!');
      navigate(`/auctions/${res.auction._id}`);
    } catch (err) {
      toast.error(err.message || 'Failed to create auction');
    } finally {
      setLoading(false);
    }
  };

  const steps = ['Item Details', 'Pricing & Timing', 'Images & Shipping'];

  return (
    <div className="page">
      <div className="container" style={{ maxWidth: 800, paddingTop: 40, paddingBottom: 64 }}>
        <h1 style={{ fontSize: 32, fontWeight: 700, marginBottom: 8 }}>List an Item</h1>
        <p style={{ color: 'var(--text-secondary)', marginBottom: 36 }}>Fill in the details below to create your auction listing.</p>

        {/* Step indicator */}
        <div style={{ display: 'flex', gap: 0, marginBottom: 40, background: 'var(--bg-surface)', border: '1px solid var(--border)', borderRadius: 12, overflow: 'hidden' }}>
          {steps.map((s, i) => (
            <button key={s} onClick={() => setStep(i + 1)} style={{
              flex: 1, padding: '14px 8px', background: step === i + 1 ? 'rgba(245,158,11,0.1)' : 'transparent',
              borderRight: i < steps.length - 1 ? '1px solid var(--border)' : 'none',
              color: step === i + 1 ? 'var(--gold)' : step > i + 1 ? 'var(--success)' : 'var(--text-muted)',
              fontSize: 13, fontWeight: 600, cursor: 'pointer',
              borderBottom: step === i + 1 ? '2px solid var(--gold)' : '2px solid transparent',
            }}>
              {step > i + 1 ? '✓ ' : `${i + 1}. `}{s}
            </button>
          ))}
        </div>

        <form onSubmit={handleSubmit}>
          {/* Step 1: Item details */}
          {step === 1 && (
            <div style={{ display: 'flex', flexDirection: 'column', gap: 20 }}>
              <div className="form-group">
                <label className="form-label">Auction Title *</label>
                <input className="form-input" placeholder="e.g., Vintage 1960s Fender Stratocaster Electric Guitar" value={form.title} onChange={e => set('title', e.target.value)} required maxLength={120} />
                <span style={{ fontSize: 12, color: 'var(--text-muted)', alignSelf: 'flex-end' }}>{form.title.length}/120</span>
              </div>
              <div className="form-group">
                <label className="form-label">Description *</label>
                <textarea className="form-input" rows={6} placeholder="Describe your item in detail — condition, history, dimensions, what's included…" value={form.description} onChange={e => set('description', e.target.value)} required style={{ resize: 'vertical' }} />
              </div>
              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 16 }}>
                <div className="form-group">
                  <label className="form-label">Category *</label>
                  <select className="form-input" value={form.category} onChange={e => set('category', e.target.value)} required>
                    <option value="">Select Category</option>
                    {CATEGORIES.map(c => <option key={c} value={c}>{c}</option>)}
                  </select>
                </div>
                <div className="form-group">
                  <label className="form-label">Condition *</label>
                  <select className="form-input" value={form.condition} onChange={e => set('condition', e.target.value)} required>
                    <option value="">Select Condition</option>
                    {CONDITIONS.map(c => <option key={c} value={c}>{c}</option>)}
                  </select>
                </div>
              </div>
              <div className="form-group">
                <label className="form-label">Tags (comma separated)</label>
                <input className="form-input" placeholder="vintage, guitar, fender, music" value={form.tags} onChange={e => set('tags', e.target.value)} />
              </div>
            </div>
          )}

          {/* Step 2: Pricing & timing */}
          {step === 2 && (
            <div style={{ display: 'flex', flexDirection: 'column', gap: 20 }}>
              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 16 }}>
                <div className="form-group">
                  <label className="form-label">Starting Price ($) *</label>
                  <input className="form-input" type="number" min="0.01" step="0.01" placeholder="1.00" value={form.startingPrice} onChange={e => set('startingPrice', e.target.value)} required />
                </div>
                <div className="form-group">
                  <label className="form-label">Min. Bid Increment ($)</label>
                  <input className="form-input" type="number" min="0.01" step="0.01" value={form.minimumBidIncrement} onChange={e => set('minimumBidIncrement', e.target.value)} />
                </div>
                <div className="form-group">
                  <label className="form-label">Reserve Price ($) <span style={{ fontWeight: 400, textTransform: 'none', color: 'var(--text-muted)' }}>optional</span></label>
                  <input className="form-input" type="number" min="0" step="0.01" placeholder="Minimum you'll accept" value={form.reservePrice} onChange={e => set('reservePrice', e.target.value)} />
                </div>
                <div className="form-group">
                  <label className="form-label">Buy It Now ($) <span style={{ fontWeight: 400, textTransform: 'none', color: 'var(--text-muted)' }}>optional</span></label>
                  <input className="form-input" type="number" min="0" step="0.01" placeholder="Instant purchase price" value={form.buyNowPrice} onChange={e => set('buyNowPrice', e.target.value)} />
                </div>
                <div className="form-group">
                  <label className="form-label">Start Time *</label>
                  <input className="form-input" type="datetime-local" value={form.startTime} onChange={e => set('startTime', e.target.value)} required />
                </div>
                <div className="form-group">
                  <label className="form-label">End Time *</label>
                  <input className="form-input" type="datetime-local" value={form.endTime} onChange={e => set('endTime', e.target.value)} required />
                </div>
              </div>
              <div style={{ padding: 16, background: 'var(--bg-elevated)', border: '1px solid var(--border)', borderRadius: 12 }}>
                <label style={{ display: 'flex', alignItems: 'center', gap: 10, cursor: 'pointer', marginBottom: 12 }}>
                  <input type="checkbox" checked={form.autoExtend.enabled} onChange={e => setForm(p => ({ ...p, autoExtend: { ...p.autoExtend, enabled: e.target.checked } }))} style={{ width: 16, height: 16, accentColor: 'var(--gold)' }} />
                  <span style={{ fontWeight: 600 }}>Auto-extend auction</span>
                  <span style={{ fontSize: 13, color: 'var(--text-muted)' }}>— prevents last-second sniping</span>
                </label>
                {form.autoExtend.enabled && (
                  <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
                    <span style={{ fontSize: 14, color: 'var(--text-secondary)' }}>Extend by</span>
                    <input className="form-input" type="number" min="1" max="30" value={form.autoExtend.minutes} onChange={e => setForm(p => ({ ...p, autoExtend: { ...p.autoExtend, minutes: e.target.value } }))} style={{ width: 80 }} />
                    <span style={{ fontSize: 14, color: 'var(--text-secondary)' }}>minutes if a bid is placed in the last N minutes</span>
                  </div>
                )}
              </div>
            </div>
          )}

          {/* Step 3: Images & shipping */}
          {step === 3 && (
            <div style={{ display: 'flex', flexDirection: 'column', gap: 24 }}>
              <div>
                <label className="form-label" style={{ display: 'block', marginBottom: 12 }}>Images *</label>
                <ImageUploader images={images} onChange={setImages} />
              </div>
              <div style={{ background: 'var(--bg-surface)', border: '1px solid var(--border)', borderRadius: 16, padding: 24 }}>
                <h3 style={{ fontSize: 16, fontWeight: 700, marginBottom: 20 }}>Shipping Details</h3>
                <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 16 }}>
                  <label style={{ display: 'flex', alignItems: 'center', gap: 10, cursor: 'pointer', gridColumn: '1 / -1' }}>
                    <input type="checkbox" checked={form.shipping.isFree} onChange={e => setShipping('isFree', e.target.checked)} style={{ width: 16, height: 16, accentColor: 'var(--gold)' }} />
                    <span style={{ fontWeight: 600 }}>Offer free shipping</span>
                  </label>
                  {!form.shipping.isFree && (
                    <div className="form-group">
                      <label className="form-label">Shipping Cost ($)</label>
                      <input className="form-input" type="number" min="0" step="0.01" placeholder="0.00" value={form.shipping.cost} onChange={e => setShipping('cost', e.target.value)} />
                    </div>
                  )}
                  <div className="form-group">
                    <label className="form-label">Ships From</label>
                    <input className="form-input" placeholder="City, State" value={form.shipping.location} onChange={e => setShipping('location', e.target.value)} />
                  </div>
                  <div className="form-group">
                    <label className="form-label">Handling Time (days)</label>
                    <input className="form-input" type="number" min="1" max="30" value={form.shipping.handlingTime} onChange={e => setShipping('handlingTime', e.target.value)} />
                  </div>
                  <label style={{ display: 'flex', alignItems: 'center', gap: 10, cursor: 'pointer' }}>
                    <input type="checkbox" checked={form.shipping.international} onChange={e => setShipping('international', e.target.checked)} style={{ width: 16, height: 16, accentColor: 'var(--gold)' }} />
                    <span>Offer international shipping</span>
                  </label>
                </div>
              </div>
            </div>
          )}

          {/* Navigation */}
          <div style={{ display: 'flex', justifyContent: 'space-between', marginTop: 32, paddingTop: 24, borderTop: '1px solid var(--border)' }}>
            {step > 1
              ? <button type="button" className="btn btn-secondary" onClick={() => setStep(p => p - 1)}>← Back</button>
              : <div />
            }
            {step < 3
              ? <button type="button" className="btn btn-primary" onClick={() => setStep(p => p + 1)}>Continue →</button>
              : <button type="submit" className="btn btn-primary btn-lg" disabled={loading}>
                  {loading ? 'Creating Auction…' : '🚀 Publish Auction'}
                </button>
            }
          </div>
        </form>
      </div>
    </div>
  );
}
