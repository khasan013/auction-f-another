// pages/Dashboard.js
import React, { useState, useEffect } from 'react';
import { useSearchParams, Link } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { bidAPI, auctionAPI, userAPI } from '../services/api';
import AuctionCard from '../components/auction/AuctionCard';
import { formatDistanceToNow } from 'date-fns';

export default function Dashboard() {
  const { user } = useAuth();
  const [searchParams, setSearchParams] = useSearchParams();
  const tab = searchParams.get('tab') || 'overview';
  const [bids, setBids] = useState([]);
  const [listings, setListings] = useState([]);
  const [watchlist, setWatchlist] = useState([]);
  const [notifications, setNotifications] = useState([]);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    setLoading(true);
    Promise.all([
      bidAPI.getMyBids({ limit: 10 }),
      auctionAPI.getMyListings({ limit: 8 }),
      userAPI.getWatchlist(),
      userAPI.getNotifications({ limit: 20 }),
    ]).then(([bRes, lRes, wRes, nRes]) => {
      setBids(bRes.bids || []);
      setListings(lRes.auctions || []);
      setWatchlist(wRes.watchlist || []);
      setNotifications(nRes.notifications || []);
    }).finally(() => setLoading(false));
  }, []);

  const TABS = [
    { key: 'overview', label: '📊 Overview' },
    { key: 'bids', label: '🔨 My Bids' },
    { key: 'listings', label: '🏷️ My Listings' },
    { key: 'watchlist', label: '👁️ Watchlist' },
    { key: 'notifications', label: '🔔 Notifications' },
  ];

  const markAllRead = async () => {
    await userAPI.markNotificationsRead([]);
    setNotifications(prev => prev.map(n => ({ ...n, isRead: true })));
  };

  return (
    <div className="page">
      <div className="container" style={{ paddingTop: 32, paddingBottom: 64 }}>
        {/* Welcome header */}
        <div style={{ display: 'flex', gap: 20, alignItems: 'center', marginBottom: 36, padding: 28, background: 'var(--bg-surface)', border: '1px solid var(--border)', borderRadius: 20 }}>
          {user?.avatar?.url
            ? <img src={user.avatar.url} alt="avatar" style={{ width: 72, height: 72, borderRadius: '50%', objectFit: 'cover', border: '3px solid var(--gold)' }} />
            : <div style={{ width: 72, height: 72, borderRadius: '50%', background: 'linear-gradient(135deg, var(--gold), var(--gold-dark))', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 28, fontWeight: 700, color: '#000' }}>{user?.name?.[0]}</div>
          }
          <div>
            <h1 style={{ fontSize: 24, fontWeight: 700, marginBottom: 4 }}>Welcome back, {user?.name?.split(' ')[0]}!</h1>
            <p style={{ color: 'var(--text-secondary)', fontSize: 14 }}>{user?.email} · {user?.isVerified ? '✅ Verified' : '⚠️ Email not verified'}</p>
          </div>
          <Link to="/profile" className="btn btn-secondary btn-sm" style={{ marginLeft: 'auto' }}>Edit Profile</Link>
        </div>

        {/* Tabs */}
        <div style={{ display: 'flex', gap: 4, marginBottom: 28, background: 'var(--bg-surface)', border: '1px solid var(--border)', borderRadius: 12, padding: 6, overflowX: 'auto' }}>
          {TABS.map(t => (
            <button key={t.key} onClick={() => setSearchParams({ tab: t.key })} style={{
              padding: '8px 16px', borderRadius: 8, fontSize: 14, fontWeight: 600, whiteSpace: 'nowrap',
              background: tab === t.key ? 'var(--bg-overlay)' : 'transparent',
              color: tab === t.key ? 'var(--gold)' : 'var(--text-muted)',
              border: tab === t.key ? '1px solid var(--border-gold)' : '1px solid transparent',
              transition: 'all 0.15s', cursor: 'pointer',
            }}>{t.label}</button>
          ))}
        </div>

        {loading ? <div style={{ display: 'flex', justifyContent: 'center', padding: 80 }}><div className="spinner" /></div> : (
          <>
            {tab === 'overview' && (
              <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(200px, 1fr))', gap: 20 }}>
                {[
                  { label: 'Total Bids', value: bids.length, icon: '🔨', color: '#f59e0b' },
                  { label: 'Active Bids', value: bids.filter(b => b.status === 'active').length, icon: '✅', color: '#10b981' },
                  { label: 'My Listings', value: listings.length, icon: '🏷️', color: '#3b82f6' },
                  { label: 'Watchlist', value: watchlist.length, icon: '👁️', color: '#8b5cf6' },
                ].map(s => (
                  <div key={s.label} style={{ background: 'var(--bg-surface)', border: '1px solid var(--border)', borderRadius: 16, padding: 24 }}>
                    <span style={{ fontSize: 32 }}>{s.icon}</span>
                    <div style={{ fontSize: 36, fontWeight: 700, color: s.color, fontFamily: 'var(--font-mono)', marginTop: 8 }}>{s.value}</div>
                    <div style={{ fontSize: 13, color: 'var(--text-muted)', marginTop: 4 }}>{s.label}</div>
                  </div>
                ))}
              </div>
            )}

            {tab === 'bids' && (
              <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
                {bids.length === 0 ? <EmptyState icon="🔨" message="You haven't placed any bids yet" /> : bids.map(bid => (
                  <div key={bid._id} style={{ background: 'var(--bg-surface)', border: `1px solid ${bid.isWinning ? 'var(--border-gold)' : 'var(--border)'}`, borderRadius: 14, padding: 20, display: 'flex', gap: 16, alignItems: 'center' }}>
                    {bid.auction?.images?.[0]?.url && <img src={bid.auction.images[0].url} alt="" style={{ width: 64, height: 64, borderRadius: 10, objectFit: 'cover', flexShrink: 0 }} />}
                    <div style={{ flex: 1 }}>
                      <div style={{ fontWeight: 600 }}>{bid.auction?.title}</div>
                      <div style={{ fontSize: 13, color: 'var(--text-muted)', marginTop: 2 }}>{formatDistanceToNow(new Date(bid.createdAt), { addSuffix: true })}</div>
                    </div>
                    <div style={{ textAlign: 'right' }}>
                      <div style={{ fontFamily: 'var(--font-mono)', fontSize: 20, fontWeight: 700, color: 'var(--gold)' }}>${bid.amount.toFixed(2)}</div>
                      <span className={`badge ${bid.isWinning ? 'badge-active' : bid.status === 'won' ? 'badge-sold' : 'badge-ended'}`} style={{ fontSize: 12, marginTop: 4 }}>
                        {bid.isWinning ? '🏆 Winning' : bid.status === 'won' ? '✅ Won' : bid.status === 'outbid' ? '⬆️ Outbid' : bid.status}
                      </span>
                    </div>
                    <Link to={`/auctions/${bid.auction?._id}`} className="btn btn-secondary btn-sm">View</Link>
                  </div>
                ))}
              </div>
            )}

            {tab === 'listings' && (
              <div>
                <div style={{ display: 'flex', justifyContent: 'flex-end', marginBottom: 20 }}>
                  <Link to="/auctions/create" className="btn btn-primary">+ New Listing</Link>
                </div>
                {listings.length === 0 ? <EmptyState icon="🏷️" message="You haven't listed any items yet" cta={{ label: 'Create your first listing', to: '/auctions/create' }} /> : (
                  <div className="grid-auto">{listings.map(a => <AuctionCard key={a._id} auction={a} />)}</div>
                )}
              </div>
            )}

            {tab === 'watchlist' && (
              watchlist.length === 0
                ? <EmptyState icon="👁️" message="Your watchlist is empty" cta={{ label: 'Browse auctions', to: '/auctions' }} />
                : <div className="grid-auto">{watchlist.map(a => <AuctionCard key={a._id} auction={a} />)}</div>
            )}

            {tab === 'notifications' && (
              <div>
                <div style={{ display: 'flex', justifyContent: 'flex-end', marginBottom: 16 }}>
                  <button className="btn btn-ghost btn-sm" onClick={markAllRead}>Mark all read</button>
                </div>
                {notifications.length === 0 ? <EmptyState icon="🔔" message="No notifications yet" /> : (
                  <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
                    {notifications.map(n => (
                      <div key={n._id} style={{
                        background: n.isRead ? 'var(--bg-surface)' : 'rgba(245,158,11,0.05)',
                        border: `1px solid ${n.isRead ? 'var(--border)' : 'var(--border-gold)'}`,
                        borderRadius: 12, padding: '14px 18px', display: 'flex', gap: 14, alignItems: 'flex-start',
                      }}>
                        {!n.isRead && <div style={{ width: 8, height: 8, borderRadius: '50%', background: 'var(--gold)', marginTop: 6, flexShrink: 0 }} />}
                        <div style={{ flex: 1 }}>
                          <div style={{ fontWeight: 600, fontSize: 14 }}>{n.title}</div>
                          <div style={{ fontSize: 13, color: 'var(--text-secondary)', marginTop: 2 }}>{n.message}</div>
                        </div>
                        <div style={{ fontSize: 12, color: 'var(--text-muted)', whiteSpace: 'nowrap' }}>{formatDistanceToNow(new Date(n.createdAt), { addSuffix: true })}</div>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            )}
          </>
        )}
      </div>
    </div>
  );
}

function EmptyState({ icon, message, cta }) {
  return (
    <div style={{ textAlign: 'center', padding: '80px 0', color: 'var(--text-muted)' }}>
      <div style={{ fontSize: 64, marginBottom: 16 }}>{icon}</div>
      <p style={{ fontSize: 16, marginBottom: cta ? 20 : 0 }}>{message}</p>
      {cta && <Link to={cta.to} className="btn btn-primary" style={{ display: 'inline-flex' }}>{cta.label}</Link>}
    </div>
  );
}
