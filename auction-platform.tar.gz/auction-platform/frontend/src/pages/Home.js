import React, { useState, useEffect } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { auctionAPI } from '../services/api';
import AuctionCard from '../components/auction/AuctionCard';

const CATEGORIES = [
  { name: 'Electronics', icon: '💻', color: '#3b82f6' },
  { name: 'Art', icon: '🎨', color: '#8b5cf6' },
  { name: 'Collectibles', icon: '🏺', color: '#f59e0b' },
  { name: 'Jewelry', icon: '💎', color: '#06b6d4' },
  { name: 'Vehicles', icon: '🚗', color: '#10b981' },
  { name: 'Fashion', icon: '👗', color: '#ec4899' },
  { name: 'Sports', icon: '⚽', color: '#f97316' },
  { name: 'Gaming', icon: '🎮', color: '#a78bfa' },
];

export default function Home() {
  const navigate = useNavigate();
  const [featured, setFeatured] = useState([]);
  const [ending, setEnding] = useState([]);
  const [searchQuery, setSearchQuery] = useState('');
  const [stats, setStats] = useState({ auctions: 0, users: 0, volume: 0 });

  useEffect(() => {
    auctionAPI.getAll({ isFeatured: true, status: 'active', limit: 4 })
      .then(r => setFeatured(r.auctions)).catch(() => {});
    auctionAPI.getAll({ status: 'active', sort: 'endTime', limit: 4 })
      .then(r => setEnding(r.auctions)).catch(() => {});
  }, []);

  const handleSearch = (e) => {
    e.preventDefault();
    if (searchQuery.trim()) navigate(`/auctions?search=${encodeURIComponent(searchQuery)}`);
  };

  return (
    <div>
      {/* Hero */}
      <section style={{
        minHeight: '92vh', display: 'flex', alignItems: 'center', position: 'relative', overflow: 'hidden',
        background: 'radial-gradient(ellipse 80% 60% at 50% 0%, rgba(245,158,11,0.08) 0%, transparent 70%), var(--bg-base)',
      }}>
        {/* Background grid */}
        <div style={{
          position: 'absolute', inset: 0, opacity: 0.04,
          backgroundImage: 'linear-gradient(rgba(245,158,11,0.5) 1px, transparent 1px), linear-gradient(90deg, rgba(245,158,11,0.5) 1px, transparent 1px)',
          backgroundSize: '60px 60px',
        }} />

        <div className="container" style={{ position: 'relative', zIndex: 1, padding: '80px 24px' }}>
          <div style={{ maxWidth: 680 }}>
            <div style={{
              display: 'inline-flex', alignItems: 'center', gap: 8, marginBottom: 24,
              background: 'rgba(245,158,11,0.1)', border: '1px solid rgba(245,158,11,0.25)',
              borderRadius: 100, padding: '6px 16px', fontSize: 13, color: 'var(--gold)',
            }}>
              <span style={{ width: 8, height: 8, background: 'var(--success)', borderRadius: '50%', animation: 'pulse 2s infinite' }} />
              Live auctions happening now
            </div>

            <h1 style={{ fontFamily: 'var(--font-display)', fontSize: 'clamp(52px, 9vw, 100px)', letterSpacing: '0.02em', lineHeight: 0.95, marginBottom: 24 }}>
              BID.<br />WIN.<br /><span style={{ color: 'var(--gold)' }}>OWN IT.</span>
            </h1>

            <p style={{ fontSize: 18, color: 'var(--text-secondary)', maxWidth: 480, lineHeight: 1.7, marginBottom: 36 }}>
              The world's most exciting real-time auction platform. Discover extraordinary items and compete to own them.
            </p>

            <form onSubmit={handleSearch} style={{ display: 'flex', gap: 0, maxWidth: 520, marginBottom: 40 }}>
              <input
                type="text"
                className="form-input"
                style={{ borderRadius: '10px 0 0 10px', fontSize: 16, border: '1px solid var(--border-gold)' }}
                placeholder="Search auctions…"
                value={searchQuery}
                onChange={e => setSearchQuery(e.target.value)}
              />
              <button type="submit" className="btn btn-primary" style={{ borderRadius: '0 10px 10px 0', padding: '0 24px', fontSize: 16, flexShrink: 0 }}>
                Search
              </button>
            </form>

            <div style={{ display: 'flex', gap: 40, flexWrap: 'wrap' }}>
              {[
                { label: 'Active Auctions', value: '2,400+' },
                { label: 'Happy Bidders', value: '48K+' },
                { label: 'Total Volume', value: '$12M+' },
              ].map(s => (
                <div key={s.label}>
                  <div style={{ fontFamily: 'var(--font-display)', fontSize: 36, color: 'var(--gold)', letterSpacing: 2 }}>{s.value}</div>
                  <div style={{ fontSize: 13, color: 'var(--text-muted)' }}>{s.label}</div>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Decorative auction items floating */}
        <div style={{ position: 'absolute', right: '5%', top: '50%', transform: 'translateY(-50%)', display: 'flex', flexDirection: 'column', gap: 16, opacity: 0.6 }} className="hero-cards">
          {['💎 Rare Diamond Ring — $4,200', '🎸 Vintage Guitar — $1,800', '🏎️ Classic Car Model — $920'].map((item, i) => (
            <div key={i} style={{
              background: 'var(--bg-surface)', border: '1px solid var(--border)',
              borderRadius: 12, padding: '12px 20px', fontSize: 14, color: 'var(--text-secondary)',
              transform: `rotate(${i % 2 === 0 ? -1.5 : 1.5}deg)`,
              boxShadow: '0 8px 32px rgba(0,0,0,0.4)',
              animation: `float${i} 4s ease-in-out infinite`,
            }}>{item}</div>
          ))}
        </div>

        <style>{`
          @keyframes float0 { 0%,100% { transform: rotate(-1.5deg) translateY(0); } 50% { transform: rotate(-1.5deg) translateY(-12px); } }
          @keyframes float1 { 0%,100% { transform: rotate(1.5deg) translateY(-6px); } 50% { transform: rotate(1.5deg) translateY(6px); } }
          @keyframes float2 { 0%,100% { transform: rotate(-1.5deg) translateY(-3px); } 50% { transform: rotate(-1.5deg) translateY(9px); } }
          @media (max-width: 900px) { .hero-cards { display: none; } }
        `}</style>
      </section>

      {/* Categories */}
      <section style={{ padding: '72px 0', background: 'var(--bg-surface)' }}>
        <div className="container">
          <SectionHeader title="Browse Categories" subtitle="Find exactly what you're looking for" link="/auctions" />
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(140px, 1fr))', gap: 16 }}>
            {CATEGORIES.map(cat => (
              <Link key={cat.name} to={`/auctions?category=${cat.name}`} style={{
                display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 10,
                padding: '24px 16px', background: 'var(--bg-elevated)',
                border: '1px solid var(--border)', borderRadius: 16,
                transition: 'all 0.2s', textDecoration: 'none',
              }}
                onMouseEnter={e => { e.currentTarget.style.borderColor = cat.color; e.currentTarget.style.transform = 'translateY(-4px)'; e.currentTarget.style.boxShadow = `0 8px 32px ${cat.color}22`; }}
                onMouseLeave={e => { e.currentTarget.style.borderColor = 'var(--border)'; e.currentTarget.style.transform = 'none'; e.currentTarget.style.boxShadow = 'none'; }}
              >
                <span style={{ fontSize: 36 }}>{cat.icon}</span>
                <span style={{ fontSize: 13, fontWeight: 600, color: 'var(--text-secondary)' }}>{cat.name}</span>
              </Link>
            ))}
          </div>
        </div>
      </section>

      {/* Featured Auctions */}
      {featured.length > 0 && (
        <section style={{ padding: '72px 0' }}>
          <div className="container">
            <SectionHeader title="Featured Auctions" subtitle="Hand-picked extraordinary items" link="/auctions?isFeatured=true" />
            <div className="grid-auto">{featured.map(a => <AuctionCard key={a._id} auction={a} />)}</div>
          </div>
        </section>
      )}

      {/* Ending Soon */}
      {ending.length > 0 && (
        <section style={{ padding: '72px 0', background: 'var(--bg-surface)' }}>
          <div className="container">
            <SectionHeader title="⏰ Ending Soon" subtitle="Don't miss out — these auctions are almost over" link="/auctions?sort=endTime" />
            <div className="grid-auto">{ending.map(a => <AuctionCard key={a._id} auction={a} />)}</div>
          </div>
        </section>
      )}

      {/* CTA */}
      <section style={{ padding: '80px 0', background: 'linear-gradient(135deg, rgba(245,158,11,0.1), rgba(245,158,11,0.03))' }}>
        <div className="container" style={{ textAlign: 'center' }}>
          <h2 style={{ fontFamily: 'var(--font-display)', fontSize: 'clamp(36px, 5vw, 60px)', letterSpacing: 2, marginBottom: 16 }}>
            READY TO <span className="text-gradient">SELL?</span>
          </h2>
          <p style={{ fontSize: 16, color: 'var(--text-secondary)', maxWidth: 460, margin: '0 auto 32px' }}>
            List your item in minutes and reach thousands of potential buyers worldwide.
          </p>
          <Link to="/auctions/create" className="btn btn-primary btn-lg">Start Selling Today →</Link>
        </div>
      </section>
    </div>
  );
}

function SectionHeader({ title, subtitle, link }) {
  return (
    <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-end', marginBottom: 32 }}>
      <div>
        <h2 style={{ fontSize: 28, fontWeight: 700, marginBottom: 4 }}>{title}</h2>
        {subtitle && <p style={{ color: 'var(--text-secondary)', fontSize: 15 }}>{subtitle}</p>}
      </div>
      {link && <Link to={link} style={{ fontSize: 14, color: 'var(--gold)', fontWeight: 600 }}>View all →</Link>}
    </div>
  );
}
