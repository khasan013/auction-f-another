import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import toast from 'react-hot-toast';

// ─── Login Page ───────────────────────────────────────────────
export function LoginPage() {
  const { login } = useAuth();
  const navigate = useNavigate();
  const [form, setForm] = useState({ email: '', password: '' });
  const [loading, setLoading] = useState(false);
  const [errors, setErrors] = useState({});

  const validate = () => {
    const e = {};
    if (!form.email) e.email = 'Email is required';
    else if (!/\S+@\S+\.\S+/.test(form.email)) e.email = 'Invalid email';
    if (!form.password) e.password = 'Password is required';
    return e;
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    const e2 = validate();
    if (Object.keys(e2).length > 0) { setErrors(e2); return; }
    setLoading(true);
    try {
      await login(form.email, form.password);
      navigate('/dashboard');
    } catch (err) {
      toast.error(err.message || 'Login failed');
    } finally {
      setLoading(false);
    }
  };

  return <AuthLayout title="Welcome back" subtitle="Sign in to your AuctionHub account">
    <form onSubmit={handleSubmit} style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>
      <div className="form-group">
        <label className="form-label">Email Address</label>
        <input className="form-input" type="email" placeholder="you@example.com" value={form.email} onChange={e => setForm(p => ({ ...p, email: e.target.value }))} />
        {errors.email && <span className="form-error">{errors.email}</span>}
      </div>
      <div className="form-group">
        <label className="form-label" style={{ display: 'flex', justifyContent: 'space-between' }}>
          Password
          <Link to="/forgot-password" style={{ color: 'var(--gold)', fontSize: 13, fontWeight: 400, textTransform: 'none' }}>Forgot password?</Link>
        </label>
        <input className="form-input" type="password" placeholder="••••••••" value={form.password} onChange={e => setForm(p => ({ ...p, password: e.target.value }))} />
        {errors.password && <span className="form-error">{errors.password}</span>}
      </div>
      <button type="submit" className="btn btn-primary btn-lg" disabled={loading} style={{ width: '100%', marginTop: 8 }}>
        {loading ? 'Signing in…' : 'Sign In'}
      </button>
    </form>
    <p style={{ textAlign: 'center', color: 'var(--text-muted)', fontSize: 14, marginTop: 24 }}>
      Don't have an account? <Link to="/register" style={{ color: 'var(--gold)', fontWeight: 600 }}>Create one</Link>
    </p>
  </AuthLayout>;
}

// ─── Register Page ────────────────────────────────────────────
export function RegisterPage() {
  const { register } = useAuth();
  const navigate = useNavigate();
  const [form, setForm] = useState({ name: '', email: '', password: '', confirm: '' });
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (form.password !== form.confirm) { toast.error('Passwords do not match'); return; }
    if (form.password.length < 6) { toast.error('Password must be at least 6 characters'); return; }
    setLoading(true);
    try {
      await register(form.name, form.email, form.password);
      toast.success('Account created! Please verify your email.');
      navigate('/dashboard');
    } catch (err) {
      toast.error(err.message || 'Registration failed');
    } finally {
      setLoading(false);
    }
  };

  return <AuthLayout title="Create account" subtitle="Join AuctionHub and start bidding today">
    <form onSubmit={handleSubmit} style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>
      {[
        { label: 'Full Name', key: 'name', type: 'text', placeholder: 'John Doe' },
        { label: 'Email Address', key: 'email', type: 'email', placeholder: 'you@example.com' },
        { label: 'Password', key: 'password', type: 'password', placeholder: '••••••••' },
        { label: 'Confirm Password', key: 'confirm', type: 'password', placeholder: '••••••••' },
      ].map(field => (
        <div key={field.key} className="form-group">
          <label className="form-label">{field.label}</label>
          <input className="form-input" type={field.type} placeholder={field.placeholder} value={form[field.key]} onChange={e => setForm(p => ({ ...p, [field.key]: e.target.value }))} required />
        </div>
      ))}
      <div style={{ padding: '12px 14px', background: 'rgba(59,130,246,0.08)', border: '1px solid rgba(59,130,246,0.2)', borderRadius: 8, fontSize: 13, color: '#60a5fa' }}>
        ℹ️ By signing up you agree to our <a href="#" style={{ color: '#60a5fa', textDecoration: 'underline' }}>Terms of Service</a> and <a href="#" style={{ color: '#60a5fa', textDecoration: 'underline' }}>Privacy Policy</a>.
      </div>
      <button type="submit" className="btn btn-primary btn-lg" disabled={loading} style={{ width: '100%' }}>
        {loading ? 'Creating account…' : 'Create Account'}
      </button>
    </form>
    <p style={{ textAlign: 'center', color: 'var(--text-muted)', fontSize: 14, marginTop: 24 }}>
      Already have an account? <Link to="/login" style={{ color: 'var(--gold)', fontWeight: 600 }}>Sign in</Link>
    </p>
  </AuthLayout>;
}

// ─── Forgot/Reset Password Pages ─────────────────────────────
export function ForgotPassword() {
  const [email, setEmail] = useState('');
  const [sent, setSent] = useState(false);
  const [loading, setLoading] = useState(false);
  const { authAPI: a } = require('../services/api');

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    try {
      const { authAPI } = require('../services/api');
      await authAPI.forgotPassword(email);
      setSent(true);
    } catch (err) {
      toast.error(err.message);
    } finally {
      setLoading(false);
    }
  };

  if (sent) return (
    <AuthLayout title="Check your email" subtitle="Password reset instructions sent">
      <div style={{ textAlign: 'center', padding: '20px 0' }}>
        <div style={{ fontSize: 64, marginBottom: 16 }}>📬</div>
        <p style={{ color: 'var(--text-secondary)', fontSize: 15, lineHeight: 1.7 }}>
          We sent a reset link to <strong style={{ color: 'var(--gold)' }}>{email}</strong>. Please check your inbox and spam folder.
        </p>
        <Link to="/login" className="btn btn-primary" style={{ display: 'inline-flex', marginTop: 24 }}>Back to Login</Link>
      </div>
    </AuthLayout>
  );

  return <AuthLayout title="Forgot password" subtitle="Enter your email to receive a reset link">
    <form onSubmit={handleSubmit} style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>
      <div className="form-group">
        <label className="form-label">Email Address</label>
        <input className="form-input" type="email" placeholder="you@example.com" value={email} onChange={e => setEmail(e.target.value)} required />
      </div>
      <button type="submit" className="btn btn-primary btn-lg" disabled={loading} style={{ width: '100%' }}>
        {loading ? 'Sending…' : 'Send Reset Link'}
      </button>
    </form>
    <p style={{ textAlign: 'center', color: 'var(--text-muted)', fontSize: 14, marginTop: 24 }}>
      <Link to="/login" style={{ color: 'var(--gold)' }}>← Back to Login</Link>
    </p>
  </AuthLayout>;
}

export function ResetPassword() {
  const { token } = require('react-router-dom').useParams();
  const navigate = useNavigate();
  const [form, setForm] = useState({ password: '', confirm: '' });
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (form.password !== form.confirm) { toast.error('Passwords do not match'); return; }
    setLoading(true);
    try {
      const { authAPI } = require('../services/api');
      await authAPI.resetPassword(token, form.password);
      toast.success('Password reset! Please log in.');
      navigate('/login');
    } catch (err) {
      toast.error(err.message);
    } finally {
      setLoading(false);
    }
  };

  return <AuthLayout title="Reset password" subtitle="Choose a new secure password">
    <form onSubmit={handleSubmit} style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>
      {[
        { label: 'New Password', key: 'password' },
        { label: 'Confirm Password', key: 'confirm' },
      ].map(f => (
        <div key={f.key} className="form-group">
          <label className="form-label">{f.label}</label>
          <input className="form-input" type="password" placeholder="••••••••" value={form[f.key]} onChange={e => setForm(p => ({ ...p, [f.key]: e.target.value }))} required minLength={6} />
        </div>
      ))}
      <button type="submit" className="btn btn-primary btn-lg" disabled={loading} style={{ width: '100%' }}>
        {loading ? 'Resetting…' : 'Reset Password'}
      </button>
    </form>
  </AuthLayout>;
}

// ─── Shared Auth Layout ───────────────────────────────────────
function AuthLayout({ title, subtitle, children }) {
  return (
    <div className="page" style={{
      display: 'flex', alignItems: 'center', justifyContent: 'center', minHeight: '100vh',
      background: 'radial-gradient(ellipse 60% 50% at 50% 0%, rgba(245,158,11,0.06) 0%, transparent 60%), var(--bg-base)',
    }}>
      <div style={{ width: '100%', maxWidth: 440, padding: '0 16px' }}>
        <div style={{ textAlign: 'center', marginBottom: 40 }}>
          <Link to="/" style={{ fontFamily: 'var(--font-display)', fontSize: 26, letterSpacing: 3, display: 'block', marginBottom: 28 }}>
            AUCTION<span style={{ color: 'var(--gold)' }}>HUB</span>
          </Link>
          <h1 style={{ fontSize: 28, fontWeight: 700, marginBottom: 8 }}>{title}</h1>
          <p style={{ color: 'var(--text-secondary)', fontSize: 15 }}>{subtitle}</p>
        </div>
        <div style={{ background: 'var(--bg-surface)', border: '1px solid var(--border)', borderRadius: 20, padding: 32 }}>
          {children}
        </div>
      </div>
    </div>
  );
}

export default LoginPage;
