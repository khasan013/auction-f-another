import React, { useState, useEffect } from 'react';
import { adminAPI } from '../../services/api';
import toast from 'react-hot-toast';

// ─── Admin Users ──────────────────────────────────────────────
export function AdminUsers() {
  const [users, setUsers] = useState([]);
  const [pagination, setPagination] = useState({});
  const [search, setSearch] = useState('');
  const [loading, setLoading] = useState(true);
  const [page, setPage] = useState(1);

  const load = async () => {
    setLoading(true);
    try {
      const res = await adminAPI.getUsers({ page, limit: 20, search });
      setUsers(res.users); setPagination(res.pagination);
    } finally { setLoading(false); }
  };

  useEffect(() => { load(); }, [page, search]);

  const handleBan = async (id, isBanned, name) => {
    const reason = isBanned ? undefined : prompt(`Ban reason for ${name}:`);
    if (!isBanned && !reason) return;
    try {
      isBanned ? await adminAPI.unbanUser(id) : await adminAPI.banUser(id, reason);
      toast.success(`User ${isBanned ? 'unbanned' : 'banned'}`);
      load();
    } catch (err) { toast.error(err.message); }
  };

  const handleRoleChange = async (id, role) => {
    try {
      await adminAPI.updateUserRole(id, role);
      toast.success('Role updated');
      load();
    } catch (err) { toast.error(err.message); }
  };

  return (
    <div className="page">
      <div className="container" style={{ paddingTop: 32, paddingBottom: 64 }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 28 }}>
          <h1 style={{ fontSize: 28, fontWeight: 700 }}>User Management</h1>
          <span style={{ color: 'var(--text-muted)', fontSize: 14 }}>{pagination.total} total users</span>
        </div>
        <input className="form-input" placeholder="Search by name or email…" value={search} onChange={e => setSearch(e.target.value)} style={{ maxWidth: 400, marginBottom: 20 }} />

        <div style={{ background: 'var(--bg-surface)', border: '1px solid var(--border)', borderRadius: 16, overflow: 'hidden' }}>
          <table style={{ width: '100%', borderCollapse: 'collapse' }}>
            <thead>
              <tr style={{ background: 'var(--bg-elevated)' }}>
                {['User', 'Email', 'Role', 'Status', 'Joined', 'Actions'].map(h => (
                  <th key={h} style={{ padding: '12px 16px', textAlign: 'left', fontSize: 12, fontWeight: 700, color: 'var(--text-muted)', textTransform: 'uppercase', letterSpacing: '0.05em' }}>{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {loading ? (
                <tr><td colSpan={6} style={{ padding: 40, textAlign: 'center' }}><div className="spinner" style={{ margin: '0 auto' }} /></td></tr>
              ) : users.map(user => (
                <tr key={user._id} style={{ borderTop: '1px solid var(--border)', transition: 'background 0.15s' }}
                  onMouseEnter={e => e.currentTarget.style.background = 'var(--bg-elevated)'}
                  onMouseLeave={e => e.currentTarget.style.background = 'transparent'}
                >
                  <td style={{ padding: '12px 16px' }}>
                    <div style={{ fontWeight: 600, fontSize: 14 }}>{user.name}</div>
                    {user.isBanned && <div style={{ fontSize: 11, color: 'var(--danger)' }}>⛔ Banned: {user.banReason}</div>}
                  </td>
                  <td style={{ padding: '12px 16px', color: 'var(--text-secondary)', fontSize: 14 }}>{user.email}</td>
                  <td style={{ padding: '12px 16px' }}>
                    <select value={user.role} onChange={e => handleRoleChange(user._id, e.target.value)} style={{
                      background: 'var(--bg-overlay)', border: '1px solid var(--border)', color: 'var(--text-primary)',
                      borderRadius: 6, padding: '4px 8px', fontSize: 13, cursor: 'pointer',
                    }}>
                      <option value="user">User</option>
                      <option value="admin">Admin</option>
                    </select>
                  </td>
                  <td style={{ padding: '12px 16px' }}>
                    {user.isVerified
                      ? <span style={{ color: 'var(--success)', fontSize: 13 }}>✓ Verified</span>
                      : <span style={{ color: 'var(--text-muted)', fontSize: 13 }}>Unverified</span>
                    }
                  </td>
                  <td style={{ padding: '12px 16px', color: 'var(--text-muted)', fontSize: 13 }}>
                    {new Date(user.createdAt).toLocaleDateString()}
                  </td>
                  <td style={{ padding: '12px 16px' }}>
                    <button onClick={() => handleBan(user._id, user.isBanned, user.name)} className="btn btn-sm" style={{
                      background: user.isBanned ? 'rgba(16,185,129,0.1)' : 'rgba(239,68,68,0.1)',
                      color: user.isBanned ? 'var(--success)' : 'var(--danger)',
                      border: `1px solid ${user.isBanned ? 'rgba(16,185,129,0.2)' : 'rgba(239,68,68,0.2)'}`,
                    }}>
                      {user.isBanned ? 'Unban' : 'Ban'}
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        {/* Pagination */}
        {pagination.total > 20 && (
          <div style={{ display: 'flex', justifyContent: 'center', gap: 8, marginTop: 24 }}>
            <button className="btn btn-secondary btn-sm" onClick={() => setPage(p => Math.max(1, p - 1))} disabled={page === 1}>← Prev</button>
            <span style={{ padding: '6px 14px', fontSize: 14, color: 'var(--text-secondary)' }}>Page {page}</span>
            <button className="btn btn-secondary btn-sm" onClick={() => setPage(p => p + 1)} disabled={users.length < 20}>Next →</button>
          </div>
        )}
      </div>
    </div>
  );
}

// ─── Admin Auctions ───────────────────────────────────────────
export function AdminAuctions() {
  const [auctions, setAuctions] = useState([]);
  const [loading, setLoading] = useState(true);
  const [status, setStatus] = useState('');
  const [page, setPage] = useState(1);
  const [pagination, setPagination] = useState({});

  const load = async () => {
    setLoading(true);
    try {
      const res = await adminAPI.getAuctions({ page, limit: 20, status });
      setAuctions(res.auctions); setPagination(res.pagination);
    } finally { setLoading(false); }
  };

  useEffect(() => { load(); }, [page, status]);

  const handleFeature = async (id) => {
    await adminAPI.toggleFeatured(id);
    toast.success('Updated!');
    load();
  };

  const handleCancel = async (id) => {
    const reason = prompt('Reason for cancellation:');
    if (!reason) return;
    await adminAPI.cancelAuction(id, reason);
    toast.success('Auction cancelled');
    load();
  };

  return (
    <div className="page">
      <div className="container" style={{ paddingTop: 32, paddingBottom: 64 }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 24 }}>
          <h1 style={{ fontSize: 28, fontWeight: 700 }}>Auction Management</h1>
          <span style={{ color: 'var(--text-muted)', fontSize: 14 }}>{pagination.total} total</span>
        </div>

        <div style={{ display: 'flex', gap: 8, marginBottom: 20, flexWrap: 'wrap' }}>
          {['', 'active', 'scheduled', 'ended', 'sold', 'cancelled'].map(s => (
            <button key={s} onClick={() => setStatus(s)} className="btn btn-sm" style={{
              background: status === s ? 'rgba(245,158,11,0.15)' : 'var(--bg-elevated)',
              border: `1px solid ${status === s ? 'var(--gold)' : 'var(--border)'}`,
              color: status === s ? 'var(--gold)' : 'var(--text-secondary)',
            }}>{s || 'All'}</button>
          ))}
        </div>

        <div style={{ background: 'var(--bg-surface)', border: '1px solid var(--border)', borderRadius: 16, overflow: 'hidden' }}>
          <table style={{ width: '100%', borderCollapse: 'collapse' }}>
            <thead>
              <tr style={{ background: 'var(--bg-elevated)' }}>
                {['Auction', 'Seller', 'Price', 'Bids', 'Status', 'Actions'].map(h => (
                  <th key={h} style={{ padding: '12px 16px', textAlign: 'left', fontSize: 12, fontWeight: 700, color: 'var(--text-muted)', textTransform: 'uppercase', letterSpacing: '0.05em' }}>{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {loading ? (
                <tr><td colSpan={6} style={{ padding: 40, textAlign: 'center' }}><div className="spinner" style={{ margin: '0 auto' }} /></td></tr>
              ) : auctions.map(a => (
                <tr key={a._id} style={{ borderTop: '1px solid var(--border)', transition: 'background 0.15s' }}
                  onMouseEnter={e => e.currentTarget.style.background = 'var(--bg-elevated)'}
                  onMouseLeave={e => e.currentTarget.style.background = 'transparent'}
                >
                  <td style={{ padding: '12px 16px', maxWidth: 280 }}>
                    <div style={{ fontWeight: 600, fontSize: 14, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{a.title}</div>
                    {a.isFeatured && <span style={{ fontSize: 11, color: 'var(--gold)' }}>⭐ Featured</span>}
                  </td>
                  <td style={{ padding: '12px 16px', fontSize: 14, color: 'var(--text-secondary)' }}>{a.seller?.name}</td>
                  <td style={{ padding: '12px 16px', fontFamily: 'var(--font-mono)', color: 'var(--gold)', fontWeight: 700 }}>${a.currentPrice?.toFixed(2)}</td>
                  <td style={{ padding: '12px 16px', color: 'var(--text-secondary)', fontSize: 14 }}>{a.totalBids}</td>
                  <td style={{ padding: '12px 16px' }}><span className={`badge badge-${a.status}`}>{a.status}</span></td>
                  <td style={{ padding: '12px 16px' }}>
                    <div style={{ display: 'flex', gap: 6 }}>
                      <button className="btn btn-sm" onClick={() => handleFeature(a._id)} style={{ background: 'rgba(245,158,11,0.1)', color: 'var(--gold)', border: '1px solid rgba(245,158,11,0.2)' }}>
                        {a.isFeatured ? '★' : '☆'}
                      </button>
                      {a.status === 'active' && (
                        <button className="btn btn-sm" onClick={() => handleCancel(a._id)} style={{ background: 'rgba(239,68,68,0.1)', color: 'var(--danger)', border: '1px solid rgba(239,68,68,0.2)' }}>✕</button>
                      )}
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        <div style={{ display: 'flex', justifyContent: 'center', gap: 8, marginTop: 24 }}>
          <button className="btn btn-secondary btn-sm" onClick={() => setPage(p => Math.max(1, p - 1))} disabled={page === 1}>← Prev</button>
          <span style={{ padding: '6px 14px', fontSize: 14, color: 'var(--text-secondary)' }}>Page {page}</span>
          <button className="btn btn-secondary btn-sm" onClick={() => setPage(p => p + 1)} disabled={auctions.length < 20}>Next →</button>
        </div>
      </div>
    </div>
  );
}

export default AdminUsers;
