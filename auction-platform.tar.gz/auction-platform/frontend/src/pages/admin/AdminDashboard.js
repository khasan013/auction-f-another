import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { adminAPI } from '../../services/api';
import { AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, PieChart, Pie, Cell } from 'recharts';

const COLORS = ['#f59e0b','#3b82f6','#10b981','#8b5cf6','#ef4444','#06b6d4','#f97316','#ec4899'];

export default function AdminDashboard() {
  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    adminAPI.getDashboard().then(r => { setData(r); setLoading(false); }).catch(() => setLoading(false));
  }, []);

  if (loading) return <div className="page" style={{ display: 'flex', justifyContent: 'center', paddingTop: 120 }}><div className="spinner" /></div>;

  const stats = data?.stats || {};
  const monthlyRevenue = data?.monthlyRevenue || [];
  const categoryBreakdown = data?.categoryBreakdown || [];

  const chartData = monthlyRevenue.map(m => ({
    name: `${m._id.year}-${String(m._id.month).padStart(2, '0')}`,
    revenue: parseFloat(m.revenue?.toFixed(2)),
    volume: parseFloat(m.volume?.toFixed(2)),
    transactions: m.count,
  }));

  return (
    <div className="page">
      <div className="container" style={{ paddingTop: 32, paddingBottom: 64 }}>
        {/* Header */}
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 36 }}>
          <div>
            <h1 style={{ fontSize: 32, fontWeight: 700 }}>Admin Dashboard</h1>
            <p style={{ color: 'var(--text-secondary)', marginTop: 4 }}>Platform overview and analytics</p>
          </div>
          <div style={{ display: 'flex', gap: 12 }}>
            {[['👥 Users', '/admin/users'], ['🏷️ Auctions', '/admin/auctions'], ['💳 Transactions', '/admin/transactions']].map(([label, to]) => (
              <Link key={to} to={to} className="btn btn-secondary btn-sm">{label}</Link>
            ))}
          </div>
        </div>

        {/* Stats grid */}
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(200px, 1fr))', gap: 20, marginBottom: 36 }}>
          {[
            { label: 'Total Users', value: stats.totalUsers?.toLocaleString(), icon: '👥', color: '#3b82f6' },
            { label: 'Total Auctions', value: stats.totalAuctions?.toLocaleString(), icon: '🏷️', color: '#8b5cf6' },
            { label: 'Active Auctions', value: stats.activeAuctions?.toLocaleString(), icon: '🔴', color: '#ef4444' },
            { label: 'Transactions', value: stats.totalTransactions?.toLocaleString(), icon: '💳', color: '#10b981' },
            { label: 'Platform Revenue', value: `$${stats.totalRevenue?.toFixed(2) || '0.00'}`, icon: '💰', color: '#f59e0b' },
            { label: 'Total Volume', value: `$${stats.totalVolume?.toFixed(2) || '0.00'}`, icon: '📊', color: '#06b6d4' },
          ].map(s => (
            <div key={s.label} style={{ background: 'var(--bg-surface)', border: '1px solid var(--border)', borderRadius: 16, padding: 20 }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start' }}>
                <div>
                  <div style={{ fontSize: 12, color: 'var(--text-muted)', textTransform: 'uppercase', letterSpacing: '0.08em', marginBottom: 8 }}>{s.label}</div>
                  <div style={{ fontSize: 28, fontWeight: 700, color: s.color, fontFamily: 'var(--font-mono)' }}>{s.value || '—'}</div>
                </div>
                <span style={{ fontSize: 28 }}>{s.icon}</span>
              </div>
            </div>
          ))}
        </div>

        {/* Charts */}
        <div style={{ display: 'grid', gridTemplateColumns: '2fr 1fr', gap: 24, marginBottom: 36 }}>
          <div style={{ background: 'var(--bg-surface)', border: '1px solid var(--border)', borderRadius: 16, padding: 24 }}>
            <h3 style={{ fontWeight: 700, marginBottom: 20 }}>Revenue & Volume (6 months)</h3>
            <ResponsiveContainer width="100%" height={260}>
              <AreaChart data={chartData}>
                <defs>
                  <linearGradient id="colorRevenue" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#f59e0b" stopOpacity={0.3} />
                    <stop offset="95%" stopColor="#f59e0b" stopOpacity={0} />
                  </linearGradient>
                  <linearGradient id="colorVolume" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#3b82f6" stopOpacity={0.2} />
                    <stop offset="95%" stopColor="#3b82f6" stopOpacity={0} />
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.05)" />
                <XAxis dataKey="name" tick={{ fill: '#606060', fontSize: 12 }} />
                <YAxis tick={{ fill: '#606060', fontSize: 12 }} />
                <Tooltip contentStyle={{ background: '#1a1a1a', border: '1px solid rgba(255,255,255,0.1)', borderRadius: 8, color: '#f5f5f5' }} />
                <Area type="monotone" dataKey="revenue" stroke="#f59e0b" strokeWidth={2} fill="url(#colorRevenue)" name="Revenue ($)" />
                <Area type="monotone" dataKey="volume" stroke="#3b82f6" strokeWidth={2} fill="url(#colorVolume)" name="Volume ($)" />
              </AreaChart>
            </ResponsiveContainer>
          </div>

          <div style={{ background: 'var(--bg-surface)', border: '1px solid var(--border)', borderRadius: 16, padding: 24 }}>
            <h3 style={{ fontWeight: 700, marginBottom: 20 }}>Categories</h3>
            <ResponsiveContainer width="100%" height={200}>
              <PieChart>
                <Pie data={categoryBreakdown.slice(0, 8)} cx="50%" cy="50%" innerRadius={50} outerRadius={85} dataKey="count" nameKey="_id">
                  {categoryBreakdown.slice(0, 8).map((_, i) => <Cell key={i} fill={COLORS[i % COLORS.length]} />)}
                </Pie>
                <Tooltip contentStyle={{ background: '#1a1a1a', border: '1px solid rgba(255,255,255,0.1)', borderRadius: 8, color: '#f5f5f5' }} />
              </PieChart>
            </ResponsiveContainer>
            <div style={{ display: 'flex', flexDirection: 'column', gap: 6, marginTop: 8 }}>
              {categoryBreakdown.slice(0, 5).map((cat, i) => (
                <div key={cat._id} style={{ display: 'flex', justifyContent: 'space-between', fontSize: 13 }}>
                  <span style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
                    <span style={{ width: 10, height: 10, borderRadius: '50%', background: COLORS[i], display: 'inline-block' }} />
                    <span style={{ color: 'var(--text-secondary)' }}>{cat._id}</span>
                  </span>
                  <span style={{ fontWeight: 600 }}>{cat.count}</span>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Recent users + auctions */}
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 24 }}>
          <div style={{ background: 'var(--bg-surface)', border: '1px solid var(--border)', borderRadius: 16, padding: 24 }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 16 }}>
              <h3 style={{ fontWeight: 700 }}>Recent Users</h3>
              <Link to="/admin/users" style={{ fontSize: 13, color: 'var(--gold)' }}>View all →</Link>
            </div>
            {data?.recentUsers?.map(u => (
              <div key={u._id} style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', padding: '10px 0', borderBottom: '1px solid var(--border)' }}>
                <div>
                  <div style={{ fontWeight: 600, fontSize: 14 }}>{u.name}</div>
                  <div style={{ fontSize: 12, color: 'var(--text-muted)' }}>{u.email}</div>
                </div>
                <div style={{ display: 'flex', gap: 8, alignItems: 'center' }}>
                  {u.role === 'admin' && <span className="badge" style={{ background: 'rgba(239,68,68,0.15)', color: 'var(--danger)', border: '1px solid rgba(239,68,68,0.25)', fontSize: 11 }}>ADMIN</span>}
                  {u.isVerified && <span style={{ color: 'var(--success)', fontSize: 14 }}>✓</span>}
                </div>
              </div>
            ))}
          </div>

          <div style={{ background: 'var(--bg-surface)', border: '1px solid var(--border)', borderRadius: 16, padding: 24 }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 16 }}>
              <h3 style={{ fontWeight: 700 }}>Active Auctions</h3>
              <Link to="/admin/auctions" style={{ fontSize: 13, color: 'var(--gold)' }}>View all →</Link>
            </div>
            {data?.recentAuctions?.map(a => (
              <div key={a._id} style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', padding: '10px 0', borderBottom: '1px solid var(--border)' }}>
                <div>
                  <div style={{ fontWeight: 600, fontSize: 14 }}>{a.title?.slice(0, 36)}…</div>
                  <div style={{ fontSize: 12, color: 'var(--text-muted)' }}>{a.totalBids} bids · by {a.seller?.name}</div>
                </div>
                <div style={{ fontFamily: 'var(--font-mono)', color: 'var(--gold)', fontWeight: 700 }}>${a.currentPrice?.toFixed(2)}</div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
