import React, { useState, useEffect } from 'react';
import { adminAPI } from '../../services/api';

export default function AdminTransactions() {
  const [transactions, setTransactions] = useState([]);
  const [loading, setLoading] = useState(true);
  const [status, setStatus] = useState('');
  const [page, setPage] = useState(1);
  const [pagination, setPagination] = useState({});

  const load = async () => {
    setLoading(true);
    try {
      const res = await adminAPI.getTransactions({ page, limit: 20, status });
      setTransactions(res.transactions);
      setPagination(res.pagination);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => { load(); }, [page, status]);

  const statusColors = {
    completed: 'var(--success)', pending: 'var(--warning)',
    failed: 'var(--danger)', refunded: 'var(--info)',
  };

  return (
    <div className="page">
      <div className="container" style={{ paddingTop: 32, paddingBottom: 64 }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 28 }}>
          <h1 style={{ fontSize: 28, fontWeight: 700 }}>Transaction Management</h1>
          <span style={{ color: 'var(--text-muted)', fontSize: 14 }}>{pagination.total || 0} total</span>
        </div>

        {/* Status filters */}
        <div style={{ display: 'flex', gap: 8, marginBottom: 20, flexWrap: 'wrap' }}>
          {['', 'pending', 'completed', 'failed', 'refunded'].map(s => (
            <button key={s} onClick={() => { setStatus(s); setPage(1); }} className="btn btn-sm" style={{
              background: status === s ? 'rgba(245,158,11,0.15)' : 'var(--bg-elevated)',
              border: `1px solid ${status === s ? 'var(--gold)' : 'var(--border)'}`,
              color: status === s ? 'var(--gold)' : 'var(--text-secondary)',
            }}>{s || 'All Statuses'}</button>
          ))}
        </div>

        <div style={{ background: 'var(--bg-surface)', border: '1px solid var(--border)', borderRadius: 16, overflow: 'hidden' }}>
          <table style={{ width: '100%', borderCollapse: 'collapse' }}>
            <thead>
              <tr style={{ background: 'var(--bg-elevated)' }}>
                {['Auction', 'Buyer', 'Seller', 'Amount', 'Fee', 'Status', 'Date'].map(h => (
                  <th key={h} style={{ padding: '12px 16px', textAlign: 'left', fontSize: 12, fontWeight: 700, color: 'var(--text-muted)', textTransform: 'uppercase', letterSpacing: '0.05em' }}>{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {loading ? (
                <tr><td colSpan={7} style={{ padding: 40, textAlign: 'center' }}><div className="spinner" style={{ margin: '0 auto' }} /></td></tr>
              ) : transactions.length === 0 ? (
                <tr><td colSpan={7} style={{ padding: 40, textAlign: 'center', color: 'var(--text-muted)' }}>No transactions found</td></tr>
              ) : transactions.map(tx => (
                <tr key={tx._id} style={{ borderTop: '1px solid var(--border)', transition: 'background 0.15s' }}
                  onMouseEnter={e => e.currentTarget.style.background = 'var(--bg-elevated)'}
                  onMouseLeave={e => e.currentTarget.style.background = 'transparent'}
                >
                  <td style={{ padding: '12px 16px', maxWidth: 200 }}>
                    <div style={{ fontSize: 13, fontWeight: 600, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
                      {tx.auction?.title || '—'}
                    </div>
                  </td>
                  <td style={{ padding: '12px 16px', fontSize: 13, color: 'var(--text-secondary)' }}>{tx.buyer?.name || '—'}</td>
                  <td style={{ padding: '12px 16px', fontSize: 13, color: 'var(--text-secondary)' }}>{tx.seller?.name || '—'}</td>
                  <td style={{ padding: '12px 16px', fontFamily: 'var(--font-mono)', fontWeight: 700, color: 'var(--gold)' }}>
                    ${tx.totalCharged?.toFixed(2)}
                  </td>
                  <td style={{ padding: '12px 16px', fontFamily: 'var(--font-mono)', fontSize: 13, color: 'var(--text-secondary)' }}>
                    ${tx.platformFee?.toFixed(2)}
                  </td>
                  <td style={{ padding: '12px 16px' }}>
                    <span style={{
                      padding: '3px 10px', borderRadius: 100, fontSize: 12, fontWeight: 600,
                      background: `${statusColors[tx.status]}22`,
                      color: statusColors[tx.status] || 'var(--text-secondary)',
                      border: `1px solid ${statusColors[tx.status]}44`,
                    }}>{tx.status}</span>
                  </td>
                  <td style={{ padding: '12px 16px', fontSize: 12, color: 'var(--text-muted)' }}>
                    {new Date(tx.createdAt).toLocaleDateString()}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        <div style={{ display: 'flex', justifyContent: 'center', gap: 8, marginTop: 24 }}>
          <button className="btn btn-secondary btn-sm" onClick={() => setPage(p => Math.max(1, p - 1))} disabled={page === 1}>← Prev</button>
          <span style={{ padding: '6px 14px', fontSize: 14, color: 'var(--text-secondary)' }}>Page {page}</span>
          <button className="btn btn-secondary btn-sm" onClick={() => setPage(p => p + 1)} disabled={transactions.length < 20}>Next →</button>
        </div>
      </div>
    </div>
  );
}
