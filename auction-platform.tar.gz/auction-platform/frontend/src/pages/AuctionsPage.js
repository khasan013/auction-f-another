import React, { useState, useEffect, useCallback } from 'react';
import { useSearchParams } from 'react-router-dom';
import { auctionAPI } from '../services/api';
import AuctionCard from '../components/auction/AuctionCard';

const CATEGORIES = ['Electronics','Fashion','Collectibles','Art','Jewelry','Vehicles','Home & Garden','Sports','Toys','Books','Music','Gaming','Health & Beauty','Business','Other'];
const CONDITIONS = ['New','Like New','Very Good','Good','Acceptable'];

export default function AuctionsPage() {
  const [searchParams, setSearchParams] = useSearchParams();
  const [auctions, setAuctions] = useState([]);
  const [pagination, setPagination] = useState({ page: 1, total: 0, pages: 1 });
  const [loading, setLoading] = useState(false);
  const [filtersOpen, setFiltersOpen] = useState(false);

  const filters = {
    search: searchParams.get('search') || '',
    category: searchParams.get('category') || '',
    status: searchParams.get('status') || 'active',
    condition: searchParams.get('condition') || '',
    sort: searchParams.get('sort') || '-createdAt',
    minPrice: searchParams.get('minPrice') || '',
    maxPrice: searchParams.get('maxPrice') || '',
    page: parseInt(searchParams.get('page') || '1'),
  };

  const setFilter = (key, value) => {
    setSearchParams(prev => {
      const next = new URLSearchParams(prev);
      if (value) next.set(key, value); else next.delete(key);
      next.set('page', '1');
      return next;
    });
  };

  const fetchAuctions = useCallback(async () => {
    setLoading(true);
    try {
      const res = await auctionAPI.getAll({ ...filters, limit: 12 });
      setAuctions(res.auctions);
      setPagination(res.pagination);
    } catch {
      setAuctions([]);
    } finally {
      setLoading(false);
    }
  }, [searchParams.toString()]);

  useEffect(() => { fetchAuctions(); }, [fetchAuctions]);

  return (
    <div className="page">
      <div className="container" style={{ paddingTop: 32, paddingBottom: 64 }}>
        {/* Header + search */}
        <div style={{ display: 'flex', gap: 16, alignItems: 'center', marginBottom: 24, flexWrap: 'wrap' }}>
          <h1 style={{ fontSize: 28, fontWeight: 700, flex: 1 }}>
            {filters.category || 'All Auctions'}
            <span style={{ fontSize: 16, color: 'var(--text-muted)', fontWeight: 400, marginLeft: 12 }}>{pagination.total} items</span>
          </h1>
          <button className="btn btn-secondary btn-sm" onClick={() => setFiltersOpen(p => !p)}>
            ⚙️ Filters {filtersOpen ? '▲' : '▼'}
          </button>
        </div>

        {/* Search bar */}
        <div style={{ marginBottom: 16 }}>
          <input
            className="form-input"
            placeholder="Search auctions by title, keywords…"
            value={filters.search}
            onChange={e => setFilter('search', e.target.value)}
            style={{ maxWidth: 500 }}
          />
        </div>

        {/* Filters panel */}
        {filtersOpen && (
          <div style={{ background: 'var(--bg-surface)', border: '1px solid var(--border)', borderRadius: 16, padding: 24, marginBottom: 24 }}>
            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(180px, 1fr))', gap: 16 }}>
              <div className="form-group">
                <label className="form-label">Category</label>
                <select className="form-input" value={filters.category} onChange={e => setFilter('category', e.target.value)}>
                  <option value="">All Categories</option>
                  {CATEGORIES.map(c => <option key={c} value={c}>{c}</option>)}
                </select>
              </div>
              <div className="form-group">
                <label className="form-label">Condition</label>
                <select className="form-input" value={filters.condition} onChange={e => setFilter('condition', e.target.value)}>
                  <option value="">Any Condition</option>
                  {CONDITIONS.map(c => <option key={c} value={c}>{c}</option>)}
                </select>
              </div>
              <div className="form-group">
                <label className="form-label">Status</label>
                <select className="form-input" value={filters.status} onChange={e => setFilter('status', e.target.value)}>
                  <option value="active">Active</option>
                  <option value="ended">Ended</option>
                  <option value="scheduled">Scheduled</option>
                </select>
              </div>
              <div className="form-group">
                <label className="form-label">Sort By</label>
                <select className="form-input" value={filters.sort} onChange={e => setFilter('sort', e.target.value)}>
                  <option value="-createdAt">Newest First</option>
                  <option value="endTime">Ending Soonest</option>
                  <option value="-currentPrice">Price: High to Low</option>
                  <option value="currentPrice">Price: Low to High</option>
                  <option value="-totalBids">Most Bids</option>
                </select>
              </div>
              <div className="form-group">
                <label className="form-label">Min Price ($)</label>
                <input className="form-input" type="number" placeholder="0" value={filters.minPrice} onChange={e => setFilter('minPrice', e.target.value)} min="0" />
              </div>
              <div className="form-group">
                <label className="form-label">Max Price ($)</label>
                <input className="form-input" type="number" placeholder="Any" value={filters.maxPrice} onChange={e => setFilter('maxPrice', e.target.value)} min="0" />
              </div>
            </div>
            <button className="btn btn-ghost btn-sm" style={{ marginTop: 12 }} onClick={() => setSearchParams({})}>
              Clear All Filters
            </button>
          </div>
        )}

        {/* Active category pills */}
        {filters.category && (
          <div style={{ display: 'flex', gap: 8, marginBottom: 16, flexWrap: 'wrap' }}>
            <span style={{ padding: '4px 12px', background: 'rgba(245,158,11,0.15)', border: '1px solid var(--border-gold)', borderRadius: 100, fontSize: 13, color: 'var(--gold)', display: 'flex', alignItems: 'center', gap: 6 }}>
              {filters.category}
              <button onClick={() => setFilter('category', '')} style={{ background: 'none', color: 'var(--gold)', fontSize: 16, lineHeight: 1, padding: 0 }}>×</button>
            </span>
          </div>
        )}

        {/* Grid */}
        {loading ? (
          <div style={{ display: 'flex', justifyContent: 'center', padding: 80 }}><div className="spinner" /></div>
        ) : auctions.length === 0 ? (
          <div style={{ textAlign: 'center', padding: '80px 0', color: 'var(--text-muted)' }}>
            <div style={{ fontSize: 64, marginBottom: 16 }}>🔍</div>
            <h3 style={{ fontSize: 20, marginBottom: 8, color: 'var(--text-secondary)' }}>No auctions found</h3>
            <p>Try adjusting your filters or search terms</p>
          </div>
        ) : (
          <>
            <div className="grid-auto">{auctions.map(a => <AuctionCard key={a._id} auction={a} />)}</div>

            {/* Pagination */}
            {pagination.pages > 1 && (
              <div style={{ display: 'flex', justifyContent: 'center', gap: 8, marginTop: 48 }}>
                {Array.from({ length: pagination.pages }, (_, i) => i + 1).map(p => (
                  <button key={p} onClick={() => setFilter('page', p)} style={{
                    width: 40, height: 40, borderRadius: 8, fontWeight: 600, fontSize: 14,
                    background: p === pagination.page ? 'var(--gold)' : 'var(--bg-elevated)',
                    color: p === pagination.page ? '#000' : 'var(--text-secondary)',
                    border: `1px solid ${p === pagination.page ? 'var(--gold)' : 'var(--border)'}`,
                    cursor: 'pointer',
                  }}>{p}</button>
                ))}
              </div>
            )}
          </>
        )}
      </div>
    </div>
  );
}
