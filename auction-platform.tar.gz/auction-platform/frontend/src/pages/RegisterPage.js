// pages/RegisterPage.js
export { RegisterPage as default } from './LoginPage';
