export { ResetPassword as default } from './LoginPage';
