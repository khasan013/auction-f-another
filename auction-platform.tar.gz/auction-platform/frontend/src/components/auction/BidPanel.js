import React, { useState, useEffect, useRef } from 'react';
import { useNavigate } from 'react-router-dom';
import { bidAPI } from '../../services/api';
import { getSocket, joinAuctionRoom, leaveAuctionRoom } from '../../services/socket';
import { useAuth } from '../../context/AuthContext';
import { useCountdown } from '../../hooks/useCountdown';
import toast from 'react-hot-toast';

export default function BidPanel({ auction: initialAuction, onUpdate }) {
  const { user } = useAuth();
  const navigate = useNavigate();
  const [auction, setAuction] = useState(initialAuction);
  const [bidAmount, setBidAmount] = useState('');
  const [loading, setLoading] = useState(false);
  const [recentBids, setRecentBids] = useState([]);
  const [liveActivity, setLiveActivity] = useState([]);
  const activityRef = useRef(null);
  const { format, isUrgent, isExpired } = useCountdown(auction.endTime);

  const minBid = (auction.currentPrice + auction.minimumBidIncrement).toFixed(2);
  const suggestedBids = [
    parseFloat(minBid),
    parseFloat(minBid) + 5,
    parseFloat(minBid) + 10,
    parseFloat(minBid) + 25,
  ];

  useEffect(() => {
    joinAuctionRoom(auction._id);
    const socket = getSocket();
    if (!socket) return;

    const handleNewBid = (data) => {
      if (data.auctionId !== auction._id) return;
      setAuction(prev => ({ ...prev, currentPrice: data.newCurrentPrice, totalBids: data.totalBids, endTime: data.endTime }));
      setBidAmount('');
      const entry = { id: Date.now(), type: 'bid', text: `${data.bid.bidder?.name || 'Someone'} bid $${data.bid.amount.toFixed(2)}`, time: new Date() };
      setLiveActivity(prev => [entry, ...prev].slice(0, 8));
      if (onUpdate) onUpdate(data);
    };

    const handleOutbid = (data) => {
      if (data.auctionId !== auction._id) return;
      toast.error(`You've been outbid! New price: $${data.newAmount}`);
    };

    const handleAuctionEnded = (data) => {
      if (data.auctionId !== auction._id) return;
      setAuction(prev => ({ ...prev, status: 'ended' }));
      const msg = data.winner ? `🏆 ${data.winner.name} won for $${data.finalPrice?.toFixed(2)}!` : 'Auction ended with no winner.';
      setLiveActivity(prev => [{ id: Date.now(), type: 'ended', text: msg, time: new Date() }, ...prev]);
      toast(msg, { icon: data.winner ? '🏆' : '🔔', duration: 6000 });
    };

    socket.on('newBid', handleNewBid);
    socket.on('outbid', handleOutbid);
    socket.on('auctionEnded', handleAuctionEnded);

    return () => {
      leaveAuctionRoom(auction._id);
      socket.off('newBid', handleNewBid);
      socket.off('outbid', handleOutbid);
      socket.off('auctionEnded', handleAuctionEnded);
    };
  }, [auction._id]);

  // Scroll activity to top on new entry
  useEffect(() => {
    if (activityRef.current) activityRef.current.scrollTop = 0;
  }, [liveActivity]);

  const handleBid = async (e) => {
    e.preventDefault();
    if (!user) { navigate('/login'); return; }
    const amount = parseFloat(bidAmount);
    if (!amount || amount < parseFloat(minBid)) {
      toast.error(`Minimum bid is $${minBid}`);
      return;
    }
    setLoading(true);
    try {
      await bidAPI.place(auction._id, { amount });
      toast.success(`🎉 Bid of $${amount.toFixed(2)} placed!`);
      setBidAmount('');
    } catch (err) {
      toast.error(err.message || 'Bid failed');
    } finally {
      setLoading(false);
    }
  };

  const isEnded = auction.status === 'ended' || auction.status === 'sold' || isExpired;
  const isOwnAuction = user?._id === (auction.seller?._id || auction.seller);

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 20 }}>
      {/* Current price block */}
      <div style={{ background: 'var(--bg-elevated)', border: '1px solid var(--border-gold)', borderRadius: 16, padding: 24 }}>
        <div style={{ fontSize: 12, color: 'var(--text-muted)', textTransform: 'uppercase', letterSpacing: '0.1em', marginBottom: 4 }}>
          {auction.totalBids === 0 ? 'Starting Bid' : 'Current Bid'}
        </div>
        <div style={{ fontSize: 42, fontWeight: 700, color: 'var(--gold)', fontFamily: 'var(--font-mono)', lineHeight: 1 }}>
          ${auction.currentPrice?.toFixed(2)}
        </div>
        <div style={{ display: 'flex', alignItems: 'center', gap: 16, marginTop: 12 }}>
          <span style={{ fontSize: 14, color: 'var(--text-secondary)' }}>
            🔨 {auction.totalBids} {auction.totalBids === 1 ? 'bid' : 'bids'}
          </span>
          {!isEnded && (
            <span className={`countdown ${isUrgent ? 'urgent' : ''}`}>
              ⏱ {format()}
            </span>
          )}
          {isEnded && <span className="badge badge-ended">Auction Ended</span>}
        </div>

        {auction.reservePrice && (
          <div style={{ marginTop: 12, fontSize: 13, color: auction.currentPrice >= auction.reservePrice ? 'var(--success)' : 'var(--text-muted)' }}>
            {auction.currentPrice >= auction.reservePrice ? '✅ Reserve price met' : '⚠️ Reserve price not yet met'}
          </div>
        )}
      </div>

      {/* Bid form */}
      {!isEnded && !isOwnAuction && (
        <div style={{ background: 'var(--bg-surface)', border: '1px solid var(--border)', borderRadius: 16, padding: 24 }}>
          <h3 style={{ fontSize: 16, fontWeight: 700, marginBottom: 16 }}>Place Your Bid</h3>

          {/* Quick bid buttons */}
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(2, 1fr)', gap: 8, marginBottom: 16 }}>
            {suggestedBids.map(amount => (
              <button key={amount} onClick={() => setBidAmount(amount.toFixed(2))} style={{
                padding: '10px', background: bidAmount === amount.toFixed(2) ? 'rgba(245,158,11,0.15)' : 'var(--bg-elevated)',
                border: `1px solid ${bidAmount === amount.toFixed(2) ? 'var(--gold)' : 'var(--border)'}`,
                borderRadius: 8, color: bidAmount === amount.toFixed(2) ? 'var(--gold)' : 'var(--text-secondary)',
                fontFamily: 'var(--font-mono)', fontSize: 14, fontWeight: 600, cursor: 'pointer', transition: 'all 0.15s',
              }}>${amount.toFixed(2)}</button>
            ))}
          </div>

          <form onSubmit={handleBid}>
            <div style={{ position: 'relative', marginBottom: 12 }}>
              <span style={{ position: 'absolute', left: 14, top: '50%', transform: 'translateY(-50%)', color: 'var(--gold)', fontWeight: 700, fontSize: 18, pointerEvents: 'none' }}>$</span>
              <input
                type="number"
                className="form-input"
                style={{ paddingLeft: 30, fontSize: 20, fontFamily: 'var(--font-mono)', fontWeight: 600 }}
                placeholder={minBid}
                value={bidAmount}
                onChange={e => setBidAmount(e.target.value)}
                min={minBid}
                step="0.01"
                disabled={loading}
              />
            </div>
            <div style={{ fontSize: 13, color: 'var(--text-muted)', marginBottom: 16 }}>
              Min bid: <span style={{ color: 'var(--gold)', fontFamily: 'var(--font-mono)' }}>${minBid}</span>
            </div>
            <button type="submit" className="btn btn-primary btn-lg" style={{ width: '100%' }} disabled={loading}>
              {loading ? 'Placing Bid…' : `🔨 Bid $${bidAmount || minBid}`}
            </button>
          </form>

          {auction.buyNowPrice && (
            <>
              <div style={{ display: 'flex', alignItems: 'center', gap: 12, margin: '16px 0' }}>
                <div style={{ flex: 1, height: 1, background: 'var(--border)' }} />
                <span style={{ fontSize: 12, color: 'var(--text-muted)' }}>or</span>
                <div style={{ flex: 1, height: 1, background: 'var(--border)' }} />
              </div>
              <button className="btn btn-secondary" style={{ width: '100%', gap: 8 }}>
                ⚡ Buy Now — ${auction.buyNowPrice?.toFixed(2)}
              </button>
            </>
          )}

          {!user && (
            <p style={{ textAlign: 'center', fontSize: 13, color: 'var(--text-muted)', marginTop: 12 }}>
              <a href="/login" style={{ color: 'var(--gold)' }}>Log in</a> or <a href="/register" style={{ color: 'var(--gold)' }}>register</a> to bid
            </p>
          )}
        </div>
      )}

      {/* Ended - payment CTA */}
      {isEnded && auction.winner && user?._id === (typeof auction.winner === 'object' ? auction.winner._id : auction.winner) && auction.paymentStatus !== 'paid' && (
        <div style={{ background: 'rgba(16,185,129,0.08)', border: '1px solid rgba(16,185,129,0.25)', borderRadius: 16, padding: 24, textAlign: 'center' }}>
          <div style={{ fontSize: 32, marginBottom: 8 }}>🎉</div>
          <h3 style={{ color: 'var(--success)', marginBottom: 8 }}>Congratulations! You won!</h3>
          <p style={{ fontSize: 14, color: 'var(--text-secondary)', marginBottom: 16 }}>Complete your payment to claim your item.</p>
          <button className="btn btn-primary btn-lg" onClick={() => navigate(`/checkout/${auction._id}`)}>
            Complete Payment — ${auction.currentPrice?.toFixed(2)}
          </button>
        </div>
      )}

      {/* Live activity feed */}
      {liveActivity.length > 0 && (
        <div style={{ background: 'var(--bg-surface)', border: '1px solid var(--border)', borderRadius: 16, padding: 16 }}>
          <h4 style={{ fontSize: 13, fontWeight: 700, color: 'var(--text-secondary)', textTransform: 'uppercase', letterSpacing: '0.05em', marginBottom: 12 }}>Live Activity</h4>
          <div ref={activityRef} style={{ maxHeight: 200, overflowY: 'auto', display: 'flex', flexDirection: 'column', gap: 8 }}>
            {liveActivity.map(entry => (
              <div key={entry.id} style={{
                display: 'flex', justifyContent: 'space-between', alignItems: 'center',
                padding: '8px 12px', background: 'var(--bg-elevated)', borderRadius: 8,
                borderLeft: `3px solid ${entry.type === 'ended' ? 'var(--gold)' : 'var(--success)'}`,
                animation: 'fadeInDown 0.3s ease',
              }}>
                <span style={{ fontSize: 13, color: 'var(--text-primary)' }}>{entry.text}</span>
                <span style={{ fontSize: 11, color: 'var(--text-muted)', whiteSpace: 'nowrap', marginLeft: 8 }}>
                  {entry.time.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' })}
                </span>
              </div>
            ))}
          </div>
        </div>
      )}

      <style>{`@keyframes fadeInDown { from { opacity:0; transform: translateY(-8px); } to { opacity:1; transform: translateY(0); } }`}</style>
    </div>
  );
}
