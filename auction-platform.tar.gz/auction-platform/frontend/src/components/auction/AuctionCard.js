import React from 'react';
import { Link } from 'react-router-dom';
import { useCountdown } from '../../hooks/useCountdown';
import { formatDistanceToNow } from 'date-fns';

export default function AuctionCard({ auction }) {
  const { format, isUrgent, isExpired } = useCountdown(auction.endTime);
  const primaryImage = auction.images?.find(i => i.isPrimary) || auction.images?.[0];

  return (
    <Link to={`/auctions/${auction._id}`} style={{ display: 'block', textDecoration: 'none' }}>
      <div className="card" style={{ overflow: 'hidden', cursor: 'pointer', transition: 'all 0.25s' }}
        onMouseEnter={e => { e.currentTarget.style.transform = 'translateY(-4px)'; e.currentTarget.style.boxShadow = '0 12px 40px rgba(0,0,0,0.4)'; }}
        onMouseLeave={e => { e.currentTarget.style.transform = 'none'; e.currentTarget.style.boxShadow = 'none'; }}
      >
        {/* Image */}
        <div style={{ position: 'relative', paddingTop: '66%', background: 'var(--bg-elevated)', overflow: 'hidden' }}>
          {primaryImage?.url ? (
            <img src={primaryImage.url} alt={auction.title} style={{ position: 'absolute', inset: 0, width: '100%', height: '100%', objectFit: 'cover', transition: 'transform 0.4s' }}
              onMouseEnter={e => e.target.style.transform = 'scale(1.05)'}
              onMouseLeave={e => e.target.style.transform = 'scale(1)'}
            />
          ) : (
            <div style={{ position: 'absolute', inset: 0, display: 'flex', alignItems: 'center', justifyContent: 'center', color: 'var(--text-muted)', fontSize: 40 }}>🖼️</div>
          )}

          {/* Badges overlay */}
          <div style={{ position: 'absolute', top: 10, left: 10, display: 'flex', gap: 6, flexWrap: 'wrap' }}>
            {auction.isFeatured && (
              <span style={{ background: 'var(--gold)', color: '#000', fontSize: 11, fontWeight: 700, padding: '3px 8px', borderRadius: 4, letterSpacing: '0.05em' }}>⭐ FEATURED</span>
            )}
            {auction.buyNowPrice && (
              <span style={{ background: 'rgba(59,130,246,0.9)', color: '#fff', fontSize: 11, fontWeight: 700, padding: '3px 8px', borderRadius: 4 }}>BUY NOW</span>
            )}
          </div>

          {/* Status / timer */}
          <div style={{ position: 'absolute', bottom: 10, right: 10 }}>
            {auction.status === 'active' && !isExpired && (
              <span className={`countdown ${isUrgent ? 'urgent' : ''}`}>
                <ClockIcon size={12} />
                {format()}
              </span>
            )}
            {(auction.status === 'ended' || isExpired) && (
              <span className="badge badge-ended">Ended</span>
            )}
            {auction.status === 'sold' && (
              <span className="badge badge-sold">Sold</span>
            )}
          </div>

          {/* Watch count */}
          {auction.watchCount > 0 && (
            <div style={{ position: 'absolute', top: 10, right: 10, background: 'rgba(0,0,0,0.7)', borderRadius: 6, padding: '3px 8px', fontSize: 12, color: 'var(--text-secondary)', display: 'flex', alignItems: 'center', gap: 4 }}>
              👁️ {auction.watchCount}
            </div>
          )}
        </div>

        {/* Content */}
        <div style={{ padding: 16 }}>
          <div style={{ fontSize: 12, color: 'var(--gold)', fontWeight: 600, textTransform: 'uppercase', letterSpacing: '0.05em', marginBottom: 6 }}>
            {auction.category}
          </div>
          <h3 style={{ fontSize: 15, fontWeight: 600, color: 'var(--text-primary)', marginBottom: 12, display: '-webkit-box', WebkitLineClamp: 2, WebkitBoxOrient: 'vertical', overflow: 'hidden', lineHeight: 1.4 }}>
            {auction.title}
          </h3>

          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-end' }}>
            <div>
              <div style={{ fontSize: 11, color: 'var(--text-muted)', marginBottom: 2, textTransform: 'uppercase', letterSpacing: '0.05em' }}>
                {auction.totalBids === 0 ? 'Starting bid' : `Current bid (${auction.totalBids})`}
              </div>
              <div style={{ fontSize: 22, fontWeight: 700, color: 'var(--gold)', fontFamily: 'var(--font-mono)' }}>
                ${auction.currentPrice?.toFixed(2)}
              </div>
            </div>

            {auction.seller && (
              <div style={{ display: 'flex', alignItems: 'center', gap: 6, fontSize: 12, color: 'var(--text-muted)' }}>
                {auction.seller.avatar?.url
                  ? <img src={auction.seller.avatar.url} alt="" style={{ width: 22, height: 22, borderRadius: '50%', objectFit: 'cover' }} />
                  : <div style={{ width: 22, height: 22, borderRadius: '50%', background: 'var(--gold)', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 10, fontWeight: 700, color: '#000' }}>{auction.seller.name?.[0]}</div>
                }
                <span>{auction.seller.name?.split(' ')[0]}</span>
              </div>
            )}
          </div>

          {auction.buyNowPrice && (
            <div style={{ marginTop: 10, padding: '8px 12px', background: 'rgba(59,130,246,0.08)', border: '1px solid rgba(59,130,246,0.2)', borderRadius: 8, fontSize: 13, color: '#60a5fa', display: 'flex', justifyContent: 'space-between' }}>
              <span>Buy Now</span>
              <span style={{ fontFamily: 'var(--font-mono)', fontWeight: 600 }}>${auction.buyNowPrice?.toFixed(2)}</span>
            </div>
          )}
        </div>
      </div>
    </Link>
  );
}

const ClockIcon = ({ size = 16 }) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5">
    <circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/>
  </svg>
);
