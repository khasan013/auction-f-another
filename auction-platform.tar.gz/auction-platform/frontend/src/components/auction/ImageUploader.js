import React, { useState, useCallback } from 'react';
import { useDropzone } from 'react-dropzone';
import { uploadAPI } from '../../services/api';
import toast from 'react-hot-toast';

export default function ImageUploader({ images = [], onChange, maxFiles = 8 }) {
  const [uploading, setUploading] = useState(false);

  const onDrop = useCallback(async (acceptedFiles) => {
    if (images.length + acceptedFiles.length > maxFiles) {
      toast.error(`Maximum ${maxFiles} images allowed`);
      return;
    }
    setUploading(true);
    try {
      const formData = new FormData();
      acceptedFiles.forEach(file => formData.append('images', file));
      const res = await uploadAPI.uploadImages(formData);
      onChange([...images, ...res.images]);
      toast.success(`${res.images.length} image(s) uploaded`);
    } catch (err) {
      toast.error('Upload failed. Please try again.');
    } finally {
      setUploading(false);
    }
  }, [images, onChange, maxFiles]);

  const { getRootProps, getInputProps, isDragActive } = useDropzone({
    onDrop,
    accept: { 'image/*': ['.jpg', '.jpeg', '.png', '.webp'] },
    maxSize: 5 * 1024 * 1024,
    disabled: uploading || images.length >= maxFiles,
  });

  const removeImage = async (index) => {
    const img = images[index];
    if (img.publicId) {
      await uploadAPI.deleteImage(img.publicId).catch(() => {});
    }
    onChange(images.filter((_, i) => i !== index));
  };

  const setPrimary = (index) => {
    onChange(images.map((img, i) => ({ ...img, isPrimary: i === index })));
  };

  return (
    <div>
      {/* Drop zone */}
      <div {...getRootProps()} style={{
        border: `2px dashed ${isDragActive ? 'var(--gold)' : 'var(--border)'}`,
        borderRadius: 12,
        padding: '32px 24px',
        textAlign: 'center',
        cursor: images.length >= maxFiles ? 'not-allowed' : 'pointer',
        background: isDragActive ? 'rgba(245,158,11,0.05)' : 'var(--bg-elevated)',
        transition: 'all 0.2s',
        opacity: images.length >= maxFiles ? 0.5 : 1,
      }}>
        <input {...getInputProps()} />
        <div style={{ fontSize: 40, marginBottom: 12 }}>{uploading ? '⏳' : '📸'}</div>
        {uploading ? (
          <p style={{ color: 'var(--gold)' }}>Uploading images…</p>
        ) : isDragActive ? (
          <p style={{ color: 'var(--gold)' }}>Drop your images here!</p>
        ) : (
          <>
            <p style={{ fontWeight: 600, marginBottom: 4 }}>
              {images.length >= maxFiles ? `Maximum ${maxFiles} images reached` : 'Drag & drop images or click to browse'}
            </p>
            <p style={{ fontSize: 13, color: 'var(--text-muted)' }}>JPG, PNG, WebP — max 5MB each — up to {maxFiles} images</p>
          </>
        )}
      </div>

      {/* Image previews */}
      {images.length > 0 && (
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(130px, 1fr))', gap: 12, marginTop: 16 }}>
          {images.map((img, index) => (
            <div key={index} style={{ position: 'relative', borderRadius: 10, overflow: 'hidden', border: `2px solid ${img.isPrimary ? 'var(--gold)' : 'var(--border)'}` }}>
              <img src={img.url} alt={`img-${index}`} style={{ width: '100%', height: 110, objectFit: 'cover', display: 'block' }} />

              {/* Overlay controls */}
              <div style={{
                position: 'absolute', inset: 0, background: 'rgba(0,0,0,0.55)',
                display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', gap: 6,
                opacity: 0, transition: 'opacity 0.2s',
              }}
                onMouseEnter={e => e.currentTarget.style.opacity = 1}
                onMouseLeave={e => e.currentTarget.style.opacity = 0}
              >
                {!img.isPrimary && (
                  <button onClick={() => setPrimary(index)} style={{
                    background: 'var(--gold)', color: '#000', border: 'none', borderRadius: 6,
                    padding: '4px 10px', fontSize: 11, fontWeight: 700, cursor: 'pointer',
                  }}>Set Primary</button>
                )}
                <button onClick={() => removeImage(index)} style={{
                  background: 'var(--danger)', color: '#fff', border: 'none', borderRadius: 6,
                  padding: '4px 10px', fontSize: 11, fontWeight: 700, cursor: 'pointer',
                }}>Remove</button>
              </div>

              {img.isPrimary && (
                <div style={{
                  position: 'absolute', top: 6, left: 6, background: 'var(--gold)', color: '#000',
                  fontSize: 10, fontWeight: 700, padding: '2px 7px', borderRadius: 4,
                }}>PRIMARY</div>
              )}
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
