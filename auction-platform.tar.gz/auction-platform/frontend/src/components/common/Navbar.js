import React, { useState, useEffect, useRef } from 'react';
import { Link, useNavigate, useLocation } from 'react-router-dom';
import { useAuth } from '../../context/AuthContext';
import { userAPI } from '../../services/api';
import { getSocket } from '../../services/socket';

export default function Navbar() {
  const { user, logout } = useAuth();
  const navigate = useNavigate();
  const location = useLocation();
  const [menuOpen, setMenuOpen] = useState(false);
  const [profileOpen, setProfileOpen] = useState(false);
  const [unreadCount, setUnreadCount] = useState(0);
  const [scrolled, setScrolled] = useState(false);
  const profileRef = useRef(null);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 20);
    window.addEventListener('scroll', onScroll);
    return () => window.removeEventListener('scroll', onScroll);
  }, []);

  useEffect(() => {
    if (user) {
      userAPI.getNotifications({ unreadOnly: true })
        .then(res => setUnreadCount(res.unreadCount || 0))
        .catch(() => {});
      const socket = getSocket();
      if (socket) {
        socket.on('outbid', () => setUnreadCount(p => p + 1));
        socket.on('auctionEnded', () => setUnreadCount(p => p + 1));
        socket.on('newBidOnYourAuction', () => setUnreadCount(p => p + 1));
      }
    }
  }, [user]);

  useEffect(() => {
    const handler = (e) => { if (profileRef.current && !profileRef.current.contains(e.target)) setProfileOpen(false); };
    document.addEventListener('mousedown', handler);
    return () => document.removeEventListener('mousedown', handler);
  }, []);

  useEffect(() => { setMenuOpen(false); setProfileOpen(false); }, [location.pathname]);

  const handleLogout = async () => { await logout(); navigate('/'); };

  const navLinks = [
    { to: '/auctions', label: 'Browse' },
    { to: '/auctions?category=Electronics', label: 'Electronics' },
    { to: '/auctions?category=Art', label: 'Art' },
    { to: '/auctions?category=Collectibles', label: 'Collectibles' },
  ];

  return (
    <header style={{
      position: 'fixed', top: 0, left: 0, right: 0, zIndex: 1000,
      background: scrolled ? 'rgba(8,8,8,0.96)' : 'rgba(8,8,8,0.8)',
      backdropFilter: 'blur(20px)',
      borderBottom: `1px solid ${scrolled ? 'rgba(245,158,11,0.15)' : 'rgba(255,255,255,0.06)'}`,
      transition: 'all 0.3s',
    }}>
      <div className="container" style={{ height: 68, display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
        {/* Logo */}
        <Link to="/" style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
          <div style={{
            width: 36, height: 36, borderRadius: 8,
            background: 'linear-gradient(135deg, #f59e0b, #d97706)',
            display: 'flex', alignItems: 'center', justifyContent: 'center',
            fontFamily: 'var(--font-display)', fontSize: 20, color: '#000', letterSpacing: 1,
          }}>A</div>
          <span style={{ fontFamily: 'var(--font-display)', fontSize: 22, letterSpacing: 3, color: 'var(--text-primary)' }}>
            AUCTION<span style={{ color: 'var(--gold)' }}>HUB</span>
          </span>
        </Link>

        {/* Desktop nav links */}
        <nav style={{ display: 'flex', alignItems: 'center', gap: 4 }} className="desktop-nav">
          {navLinks.map(link => (
            <Link key={link.to} to={link.to} style={{
              padding: '6px 14px', borderRadius: 8, fontSize: 14, fontWeight: 500,
              color: location.pathname === link.to.split('?')[0] ? 'var(--gold)' : 'var(--text-secondary)',
              transition: 'color 0.2s',
            }}
              onMouseEnter={e => e.target.style.color = 'var(--text-primary)'}
              onMouseLeave={e => e.target.style.color = location.pathname === link.to.split('?')[0] ? 'var(--gold)' : 'var(--text-secondary)'}
            >{link.label}</Link>
          ))}
        </nav>

        {/* Right side */}
        <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
          {user ? (
            <>
              <Link to="/auctions/create" className="btn btn-primary btn-sm">+ Sell</Link>

              {/* Notifications */}
              <Link to="/dashboard?tab=notifications" style={{ position: 'relative', padding: 8, color: 'var(--text-secondary)' }}>
                <BellIcon />
                {unreadCount > 0 && (
                  <span style={{
                    position: 'absolute', top: 4, right: 4, minWidth: 18, height: 18,
                    background: 'var(--danger)', borderRadius: '50%', fontSize: 11, fontWeight: 700,
                    color: '#fff', display: 'flex', alignItems: 'center', justifyContent: 'center',
                    border: '2px solid var(--bg-base)',
                  }}>{unreadCount > 9 ? '9+' : unreadCount}</span>
                )}
              </Link>

              {/* Profile dropdown */}
              <div ref={profileRef} style={{ position: 'relative' }}>
                <button onClick={() => setProfileOpen(p => !p)} style={{
                  display: 'flex', alignItems: 'center', gap: 8, background: 'var(--bg-elevated)',
                  border: '1px solid var(--border)', borderRadius: 10, padding: '6px 10px',
                  transition: 'border-color 0.2s',
                }}
                  onMouseEnter={e => e.currentTarget.style.borderColor = 'var(--gold)'}
                  onMouseLeave={e => e.currentTarget.style.borderColor = 'var(--border)'}
                >
                  {user.avatar?.url
                    ? <img src={user.avatar.url} alt="avatar" style={{ width: 28, height: 28, borderRadius: '50%', objectFit: 'cover' }} />
                    : <div style={{ width: 28, height: 28, borderRadius: '50%', background: 'var(--gold)', display: 'flex', alignItems: 'center', justifyContent: 'center', fontWeight: 700, fontSize: 13, color: '#000' }}>{user.name[0].toUpperCase()}</div>
                  }
                  <span style={{ fontSize: 14, fontWeight: 600, maxWidth: 100, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{user.name.split(' ')[0]}</span>
                  <ChevronIcon style={{ transform: profileOpen ? 'rotate(180deg)' : 'none', transition: 'transform 0.2s' }} />
                </button>

                {profileOpen && (
                  <div style={{
                    position: 'absolute', right: 0, top: 'calc(100% + 8px)', width: 220,
                    background: 'var(--bg-elevated)', border: '1px solid var(--border)',
                    borderRadius: 12, padding: 8, boxShadow: '0 20px 60px rgba(0,0,0,0.6)',
                    animation: 'fadeInDown 0.15s ease',
                  }}>
                    {[
                      { to: '/dashboard', label: '📊 Dashboard' },
                      { to: '/dashboard?tab=bids', label: '🔨 My Bids' },
                      { to: '/dashboard?tab=listings', label: '🏷️ My Listings' },
                      { to: '/dashboard?tab=watchlist', label: '👁️ Watchlist' },
                      { to: '/profile', label: '⚙️ Settings' },
                      ...(user.role === 'admin' ? [{ to: '/admin', label: '🛡️ Admin Panel' }] : []),
                    ].map(item => (
                      <Link key={item.to} to={item.to} style={{
                        display: 'block', padding: '10px 12px', borderRadius: 8, fontSize: 14,
                        color: 'var(--text-secondary)', transition: 'all 0.15s',
                      }}
                        onMouseEnter={e => { e.target.style.background = 'var(--bg-overlay)'; e.target.style.color = 'var(--text-primary)'; }}
                        onMouseLeave={e => { e.target.style.background = 'transparent'; e.target.style.color = 'var(--text-secondary)'; }}
                      >{item.label}</Link>
                    ))}
                    <div style={{ height: 1, background: 'var(--border)', margin: '8px 0' }} />
                    <button onClick={handleLogout} style={{
                      display: 'block', width: '100%', textAlign: 'left', padding: '10px 12px',
                      borderRadius: 8, fontSize: 14, color: 'var(--danger)', background: 'transparent',
                      transition: 'background 0.15s',
                    }}
                      onMouseEnter={e => e.target.style.background = 'rgba(239,68,68,0.08)'}
                      onMouseLeave={e => e.target.style.background = 'transparent'}
                    >🚪 Log Out</button>
                  </div>
                )}
              </div>
            </>
          ) : (
            <div style={{ display: 'flex', gap: 8 }}>
              <Link to="/login" className="btn btn-ghost btn-sm">Log In</Link>
              <Link to="/register" className="btn btn-primary btn-sm">Sign Up</Link>
            </div>
          )}
        </div>
      </div>

      <style>{`
        @keyframes fadeInDown { from { opacity: 0; transform: translateY(-8px); } to { opacity: 1; transform: translateY(0); } }
        @media (max-width: 768px) { .desktop-nav { display: none !important; } }
      `}</style>
    </header>
  );
}

const BellIcon = () => (
  <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
    <path d="M18 8A6 6 0 0 0 6 8c0 7-3 9-3 9h18s-3-2-3-9"/><path d="M13.73 21a2 2 0 0 1-3.46 0"/>
  </svg>
);
const ChevronIcon = ({ style }) => (
  <svg style={style} width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
    <polyline points="6 9 12 15 18 9"/>
  </svg>
);
