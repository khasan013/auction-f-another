import React from 'react';

export default function LoadingScreen() {
  return (
    <div style={{ minHeight: '100vh', display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', background: 'var(--bg-base)', gap: 20 }}>
      <div style={{ fontFamily: 'var(--font-display)', fontSize: 32, letterSpacing: 4 }}>
        AUCTION<span style={{ color: 'var(--gold)' }}>HUB</span>
      </div>
      <div className="spinner" />
    </div>
  );
}
