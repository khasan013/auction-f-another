// Footer.js
import React from 'react';
import { Link } from 'react-router-dom';

export default function Footer() {
  return (
    <footer style={{ background: 'var(--bg-surface)', borderTop: '1px solid var(--border)', padding: '48px 0 24px' }}>
      <div className="container">
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(200px, 1fr))', gap: 40, marginBottom: 40 }}>
          <div>
            <div style={{ fontFamily: 'var(--font-display)', fontSize: 24, letterSpacing: 3, marginBottom: 12 }}>
              AUCTION<span style={{ color: 'var(--gold)' }}>HUB</span>
            </div>
            <p style={{ color: 'var(--text-muted)', fontSize: 14, lineHeight: 1.7 }}>
              The premier marketplace for real-time online auctions. Buy, sell, and discover extraordinary items.
            </p>
          </div>
          {[
            { title: 'Marketplace', links: [['Browse All', '/auctions'], ['Electronics', '/auctions?category=Electronics'], ['Art & Collectibles', '/auctions?category=Art'], ['Vehicles', '/auctions?category=Vehicles']] },
            { title: 'Account', links: [['Dashboard', '/dashboard'], ['My Bids', '/dashboard?tab=bids'], ['Sell an Item', '/auctions/create'], ['Settings', '/profile']] },
            { title: 'Support', links: [['Help Center', '#'], ['How It Works', '#'], ['Seller Guide', '#'], ['Contact Us', '#']] },
          ].map(col => (
            <div key={col.title}>
              <h4 style={{ fontSize: 12, fontWeight: 700, letterSpacing: '0.1em', textTransform: 'uppercase', color: 'var(--text-muted)', marginBottom: 16 }}>{col.title}</h4>
              {col.links.map(([label, to]) => (
                <Link key={label} to={to} style={{ display: 'block', fontSize: 14, color: 'var(--text-secondary)', marginBottom: 10, transition: 'color 0.2s' }}
                  onMouseEnter={e => e.target.style.color = 'var(--gold)'}
                  onMouseLeave={e => e.target.style.color = 'var(--text-secondary)'}
                >{label}</Link>
              ))}
            </div>
          ))}
        </div>
        <div style={{ height: 1, background: 'var(--border)', marginBottom: 24 }} />
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', flexWrap: 'wrap', gap: 12 }}>
          <p style={{ fontSize: 13, color: 'var(--text-muted)' }}>© {new Date().getFullYear()} AuctionHub. All rights reserved.</p>
          <div style={{ display: 'flex', gap: 20 }}>
            {['Privacy Policy', 'Terms of Service', 'Cookie Policy'].map(item => (
              <a key={item} href="#" style={{ fontSize: 13, color: 'var(--text-muted)' }}
                onMouseEnter={e => e.target.style.color = 'var(--text-secondary)'}
                onMouseLeave={e => e.target.style.color = 'var(--text-muted)'}
              >{item}</a>
            ))}
          </div>
        </div>
      </div>
    </footer>
  );
}
