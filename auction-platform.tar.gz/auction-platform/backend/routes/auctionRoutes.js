const express = require('express');
const router = express.Router();
const {
  getAuctions, getAuction, createAuction, updateAuction,
  deleteAuction, toggleWatch, getMyListings, getCategoryStats,
} = require('../controllers/auctionController');
const { protect, optionalAuth } = require('../middleware/auth');

router.get('/', optionalAuth, getAuctions);
router.get('/my/listings', protect, getMyListings);
router.get('/categories/stats', getCategoryStats);
router.get('/:id', optionalAuth, getAuction);
router.post('/', protect, createAuction);
router.put('/:id', protect, updateAuction);
router.delete('/:id', protect, deleteAuction);
router.post('/:id/watch', protect, toggleWatch);

module.exports = router;
