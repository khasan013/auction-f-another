// routes/bidRoutes.js
const express = require('express');
const router = express.Router();
const { placeBid, getAuctionBids, getMyBids } = require('../controllers/bidController');
const { protect } = require('../middleware/auth');

router.post('/:auctionId', protect, placeBid);
router.get('/:auctionId', getAuctionBids);
router.get('/user/my', protect, getMyBids);

module.exports = router;
