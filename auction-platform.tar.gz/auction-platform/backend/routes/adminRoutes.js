const express = require('express');
const router = express.Router();
const { getDashboard, getUsers, banUser, unbanUser, updateUserRole, getAuctions, toggleFeatured, cancelAuction, getTransactions } = require('../controllers/adminController');
const { protect, authorize } = require('../middleware/auth');

router.use(protect, authorize('admin'));

router.get('/dashboard', getDashboard);
router.get('/users', getUsers);
router.put('/users/:id/ban', banUser);
router.put('/users/:id/unban', unbanUser);
router.put('/users/:id/role', updateUserRole);
router.get('/auctions', getAuctions);
router.put('/auctions/:id/feature', toggleFeatured);
router.put('/auctions/:id/cancel', cancelAuction);
router.get('/transactions', getTransactions);

module.exports = router;
