const express = require('express');
const router = express.Router();
const { createPaymentIntent, confirmPayment, stripeWebhook, getMyTransactions } = require('../controllers/paymentController');
const { protect } = require('../middleware/auth');

router.post('/webhook', stripeWebhook); // raw body — mounted before json middleware in server.js
router.post('/create-intent/:auctionId', protect, createPaymentIntent);
router.post('/confirm/:auctionId', protect, confirmPayment);
router.get('/transactions', protect, getMyTransactions);

module.exports = router;
