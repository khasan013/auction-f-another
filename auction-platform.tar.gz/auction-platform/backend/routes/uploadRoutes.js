const express = require('express');
const router = express.Router();
const { protect } = require('../middleware/auth');
const { upload, cloudinary } = require('../config/cloudinary');

// @route   POST /api/upload/images
router.post('/images', protect, upload.array('images', 8), async (req, res, next) => {
  try {
    if (!req.files || req.files.length === 0) {
      return res.status(400).json({ success: false, message: 'No files uploaded' });
    }
    const images = req.files.map((file, i) => ({
      url: file.path,
      publicId: file.filename,
      isPrimary: i === 0,
    }));
    res.json({ success: true, images });
  } catch (err) {
    next(err);
  }
});

// @route   DELETE /api/upload/image/:publicId
router.delete('/image/:publicId', protect, async (req, res, next) => {
  try {
    await cloudinary.uploader.destroy(req.params.publicId);
    res.json({ success: true, message: 'Image deleted' });
  } catch (err) {
    next(err);
  }
});

module.exports = router;
