const express = require('express');
const router = express.Router();
const { updateProfile, updateAvatar, getPublicProfile, getNotifications, markNotificationsRead, getWatchlist } = require('../controllers/userController');
const { protect } = require('../middleware/auth');
const { upload } = require('../config/cloudinary');

router.put('/profile', protect, updateProfile);
router.put('/avatar', protect, upload.single('avatar'), updateAvatar);
router.get('/notifications', protect, getNotifications);
router.put('/notifications/read', protect, markNotificationsRead);
router.get('/watchlist', protect, getWatchlist);
router.get('/:id/profile', getPublicProfile);

module.exports = router;
