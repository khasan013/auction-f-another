const mongoose = require('mongoose');
const bcrypt = require('bcryptjs');
require('dotenv').config();

const User = require('../models/User');
const Auction = require('../models/Auction');
const Bid = require('../models/Bid');

const MONGO_URI = process.env.MONGO_URI || 'mongodb://localhost:27017/auction_platform';

const seedData = async () => {
  try {
    await mongoose.connect(MONGO_URI);
    console.log('✅ Connected to MongoDB');

    // Clear existing data
    await Promise.all([User.deleteMany({}), Auction.deleteMany({}), Bid.deleteMany({})]);
    console.log('🗑️  Cleared existing data');

    // Create admin user
    const admin = await User.create({
      name: 'Admin User',
      email: 'admin@auctionhub.com',
      password: 'Admin1234!',
      role: 'admin',
      isVerified: true,
    });

    // Create seller users
    const sellers = await User.insertMany([
      { name: 'Alice Johnson', email: 'alice@example.com', password: await bcrypt.hash('Test1234!', 12), isVerified: true, sellerRating: 4.8, totalSales: 24 },
      { name: 'Bob Martinez', email: 'bob@example.com', password: await bcrypt.hash('Test1234!', 12), isVerified: true, sellerRating: 4.5, totalSales: 12 },
      { name: 'Carol White', email: 'carol@example.com', password: await bcrypt.hash('Test1234!', 12), isVerified: true, sellerRating: 4.9, totalSales: 56 },
    ]);

    // Create buyer users
    const buyers = await User.insertMany([
      { name: 'Dave Brown', email: 'dave@example.com', password: await bcrypt.hash('Test1234!', 12), isVerified: true },
      { name: 'Eva Green', email: 'eva@example.com', password: await bcrypt.hash('Test1234!', 12), isVerified: true },
    ]);

    // Create auctions
    const now = new Date();
    const auctionData = [
      {
        title: 'Apple MacBook Pro 16" M3 Max — Barely Used',
        description: 'Pristine condition MacBook Pro with M3 Max chip, 36GB RAM, 1TB SSD. Purchased 3 months ago. Includes original box, charger, and USB-C hub. No scratches, runs perfectly.',
        category: 'Electronics',
        condition: 'Like New',
        startingPrice: 1800,
        currentPrice: 2100,
        minimumBidIncrement: 50,
        startTime: new Date(now - 2 * 60 * 60 * 1000),
        endTime: new Date(now.getTime() + 2 * 24 * 60 * 60 * 1000),
        status: 'active',
        seller: sellers[0]._id,
        isFeatured: true,
        totalBids: 6,
        images: [{ url: 'https://images.unsplash.com/photo-1517336714731-489689fd1ca8?w=800', isPrimary: true }],
        shipping: { isFree: false, cost: 25, location: 'San Francisco, CA', handlingTime: 2 },
        tags: ['apple', 'macbook', 'laptop', 'electronics'],
      },
      {
        title: 'Signed Basquiat Limited Edition Print — Certificate of Authenticity',
        description: 'Rare limited edition screen print by Jean-Michel Basquiat, numbered 47/100. Comes with Certificate of Authenticity from the Basquiat Estate. Professionally framed.',
        category: 'Art',
        condition: 'Very Good',
        startingPrice: 5000,
        currentPrice: 6800,
        minimumBidIncrement: 200,
        startTime: new Date(now - 1 * 24 * 60 * 60 * 1000),
        endTime: new Date(now.getTime() + 5 * 24 * 60 * 60 * 1000),
        status: 'active',
        seller: sellers[2]._id,
        isFeatured: true,
        totalBids: 8,
        images: [{ url: 'https://images.unsplash.com/photo-1536924940846-227afb31e2a5?w=800', isPrimary: true }],
        shipping: { isFree: true, location: 'New York, NY', handlingTime: 5, international: true },
        tags: ['art', 'basquiat', 'print', 'collectible'],
      },
      {
        title: 'Rolex Submariner Date — Ref 116610LN Black Dial',
        description: 'Authentic Rolex Submariner Date in stainless steel with black ceramic bezel. Full set including original box, papers (2019), and extra links. Serviced by authorized dealer in 2023.',
        category: 'Jewelry',
        condition: 'Very Good',
        startingPrice: 9000,
        currentPrice: 11500,
        reservePrice: 10000,
        minimumBidIncrement: 250,
        startTime: new Date(now - 3 * 60 * 60 * 1000),
        endTime: new Date(now.getTime() + 3 * 24 * 60 * 60 * 1000),
        status: 'active',
        seller: sellers[1]._id,
        isFeatured: true,
        totalBids: 14,
        images: [{ url: 'https://images.unsplash.com/photo-1523170335258-f5ed11844a49?w=800', isPrimary: true }],
        shipping: { isFree: true, location: 'Miami, FL', handlingTime: 1 },
        tags: ['rolex', 'watch', 'luxury', 'submariner'],
      },
      {
        title: 'Nintendo Game & Watch Ball — Original 1980 Complete in Box',
        description: 'Extremely rare original 1980 Nintendo Game & Watch Ball (GW-02) in complete, working condition with original box, foam insert, and instruction booklet. A true collector\'s gem.',
        category: 'Gaming',
        condition: 'Good',
        startingPrice: 400,
        currentPrice: 620,
        minimumBidIncrement: 20,
        startTime: new Date(now - 5 * 60 * 60 * 1000),
        endTime: new Date(now.getTime() + 18 * 60 * 60 * 1000),
        status: 'active',
        seller: sellers[0]._id,
        totalBids: 11,
        images: [{ url: 'https://images.unsplash.com/photo-1493711662062-fa541adb3fc8?w=800', isPrimary: true }],
        shipping: { isFree: false, cost: 12, location: 'Portland, OR', handlingTime: 3 },
        tags: ['nintendo', 'retro', 'gaming', 'collectible'],
      },
      {
        title: '1967 Ford Mustang Fastback — Numbers Matching 390ci',
        description: 'Stunning 1967 Mustang Fastback in Candy Apple Red. Original 390ci V8, numbers-matching. Full frame-off restoration completed 2021. Power steering, front disc brakes. Must see.',
        category: 'Vehicles',
        condition: 'Very Good',
        startingPrice: 45000,
        currentPrice: 52000,
        buyNowPrice: 75000,
        minimumBidIncrement: 1000,
        startTime: new Date(now - 2 * 24 * 60 * 60 * 1000),
        endTime: new Date(now.getTime() + 7 * 24 * 60 * 60 * 1000),
        status: 'active',
        seller: sellers[2]._id,
        isFeatured: true,
        totalBids: 5,
        images: [{ url: 'https://images.unsplash.com/photo-1494976388531-d1058494cdd8?w=800', isPrimary: true }],
        shipping: { isFree: false, cost: 800, location: 'Austin, TX', handlingTime: 14 },
        tags: ['mustang', 'ford', 'classic', 'car', 'muscle'],
      },
      {
        title: 'Hermès Birkin 35 Togo Leather Gold Hardware — Rouge Casaque',
        description: 'Authentic Hermès Birkin 35 in vibrant Rouge Casaque Togo leather with Gold hardware. Comes with original dustbag, box, lock, keys, rain cover, and receipt from Paris flagship.',
        category: 'Fashion',
        condition: 'Like New',
        startingPrice: 12000,
        currentPrice: 14500,
        minimumBidIncrement: 500,
        startTime: new Date(now - 4 * 60 * 60 * 1000),
        endTime: new Date(now.getTime() + 4 * 24 * 60 * 60 * 1000),
        status: 'active',
        seller: sellers[1]._id,
        totalBids: 9,
        images: [{ url: 'https://images.unsplash.com/photo-1548036328-c9fa89d128fa?w=800', isPrimary: true }],
        shipping: { isFree: true, location: 'Beverly Hills, CA', handlingTime: 2 },
        tags: ['hermes', 'birkin', 'luxury', 'handbag', 'fashion'],
      },
    ];

    const auctions = await Auction.insertMany(auctionData);
    console.log(`✅ Created ${auctions.length} auctions`);

    // Create some bids
    const bidData = [];
    for (const auction of auctions) {
      const numBids = auction.totalBids;
      let price = auction.startingPrice;
      for (let i = 0; i < Math.min(numBids, 5); i++) {
        price += auction.minimumBidIncrement * (Math.floor(Math.random() * 3) + 1);
        bidData.push({
          auction: auction._id,
          bidder: buyers[i % buyers.length]._id,
          amount: price,
          isWinning: i === Math.min(numBids, 5) - 1,
          status: i === Math.min(numBids, 5) - 1 ? 'active' : 'outbid',
          isOutbid: i < Math.min(numBids, 5) - 1,
        });
      }
    }
    await Bid.insertMany(bidData);
    console.log(`✅ Created ${bidData.length} bids`);

    console.log('\n🎉 Seed data created successfully!\n');
    console.log('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━');
    console.log('Admin credentials:');
    console.log('  Email:    admin@auctionhub.com');
    console.log('  Password: Admin1234!');
    console.log('\nTest user credentials (all use: Test1234!):');
    console.log('  alice@example.com  (seller, 4.8★)');
    console.log('  bob@example.com    (seller, 4.5★)');
    console.log('  carol@example.com  (seller, 4.9★)');
    console.log('  dave@example.com   (buyer)');
    console.log('  eva@example.com    (buyer)');
    console.log('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n');

    process.exit(0);
  } catch (err) {
    console.error('❌ Seed error:', err);
    process.exit(1);
  }
};

seedData();
