const jwt = require('jsonwebtoken');
const logger = require('../config/logger');

let io;

const initializeSocket = (socketIO) => {
  io = socketIO;

  // Authenticate socket connections
  io.use((socket, next) => {
    const token = socket.handshake.auth?.token || socket.handshake.headers?.authorization?.split(' ')[1];
    if (token) {
      try {
        const decoded = jwt.verify(token, process.env.JWT_SECRET);
        socket.userId = decoded.id;
        socket.userRole = decoded.role;
      } catch (_) {
        // Anonymous users allowed for auction watching
      }
    }
    next();
  });

  io.on('connection', (socket) => {
    logger.debug(`Socket connected: ${socket.id} | user: ${socket.userId || 'anonymous'}`);

    // Join user's personal room for notifications
    if (socket.userId) {
      socket.join(`user:${socket.userId}`);
    }

    // Join auction room to receive live bid updates
    socket.on('joinAuction', (auctionId) => {
      socket.join(`auction:${auctionId}`);
      logger.debug(`Socket ${socket.id} joined auction:${auctionId}`);
    });

    socket.on('leaveAuction', (auctionId) => {
      socket.leave(`auction:${auctionId}`);
    });

    // Admin room
    if (socket.userRole === 'admin') {
      socket.join('admin');
    }

    // Typing indicator for bid input
    socket.on('bidTyping', ({ auctionId, isTyping }) => {
      socket.to(`auction:${auctionId}`).emit('userTyping', {
        userId: socket.userId,
        isTyping,
      });
    });

    socket.on('disconnect', () => {
      logger.debug(`Socket disconnected: ${socket.id}`);
    });
  });

  logger.info('✅ Socket.io initialized');
};

const getIO = () => {
  if (!io) throw new Error('Socket.io not initialized');
  return io;
};

module.exports = { initializeSocket, getIO };
