const Notification = require('../models/Notification');
const logger = require('../config/logger');

const createNotification = async ({ recipient, type, title, message, auction }) => {
  try {
    await Notification.create({ recipient, type, title, message, auction });
  } catch (err) {
    logger.error(`Failed to create notification: ${err.message}`);
  }
};

module.exports = { createNotification };
