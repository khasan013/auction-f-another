const nodemailer = require('nodemailer');
const logger = require('../config/logger');

const transporter = nodemailer.createTransport({
  host: process.env.SMTP_HOST,
  port: process.env.SMTP_PORT,
  auth: { user: process.env.SMTP_EMAIL, pass: process.env.SMTP_PASSWORD },
});

const templates = {
  emailVerification: ({ name, verifyUrl }) => ({
    subject: 'Verify your AuctionHub email',
    html: `
      <div style="font-family:sans-serif;max-width:600px;margin:0 auto;padding:40px 20px;background:#0a0a0a;color:#fff;border-radius:12px;">
        <h1 style="color:#f59e0b;margin-bottom:8px;">AuctionHub</h1>
        <h2 style="font-weight:400;">Welcome, ${name}!</h2>
        <p style="color:#aaa;">Please verify your email address to get started.</p>
        <a href="${verifyUrl}" style="display:inline-block;margin-top:24px;padding:14px 32px;background:#f59e0b;color:#000;border-radius:8px;text-decoration:none;font-weight:700;font-size:16px;">Verify Email</a>
        <p style="margin-top:32px;color:#666;font-size:13px;">Link expires in 24 hours. If you didn't register, ignore this email.</p>
      </div>
    `,
  }),
  passwordReset: ({ name, resetUrl }) => ({
    subject: 'Reset your AuctionHub password',
    html: `
      <div style="font-family:sans-serif;max-width:600px;margin:0 auto;padding:40px 20px;background:#0a0a0a;color:#fff;border-radius:12px;">
        <h1 style="color:#f59e0b;">AuctionHub</h1>
        <h2 style="font-weight:400;">Password Reset, ${name}</h2>
        <p style="color:#aaa;">Click below to reset your password. This link expires in 1 hour.</p>
        <a href="${resetUrl}" style="display:inline-block;margin-top:24px;padding:14px 32px;background:#f59e0b;color:#000;border-radius:8px;text-decoration:none;font-weight:700;font-size:16px;">Reset Password</a>
        <p style="margin-top:32px;color:#666;font-size:13px;">If you didn't request this, ignore this email. Your password won't change.</p>
      </div>
    `,
  }),
};

const sendEmail = async ({ to, subject, template, data }) => {
  try {
    const tmpl = templates[template]?.(data) || { subject, html: data?.html || '' };
    await transporter.sendMail({
      from: `"${process.env.FROM_NAME}" <${process.env.FROM_EMAIL}>`,
      to,
      subject: tmpl.subject || subject,
      html: tmpl.html,
    });
    logger.info(`Email sent to ${to}: ${tmpl.subject}`);
  } catch (err) {
    logger.error(`Email failed to ${to}: ${err.message}`);
    throw err;
  }
};

module.exports = { sendEmail };
