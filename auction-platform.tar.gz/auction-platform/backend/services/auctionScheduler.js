const Auction = require('../models/Auction');
const Bid = require('../models/Bid');
const User = require('../models/User');
const { createNotification } = require('./notificationService');
const { getIO } = require('./socketService');
const logger = require('../config/logger');

// Poll every 30 seconds for auction events
const POLL_INTERVAL = 30 * 1000;

const scheduleAuctionJobs = () => {
  logger.info('⏰ Auction scheduler started');

  // Activate scheduled auctions
  setInterval(async () => {
    try {
      const now = new Date();
      const toActivate = await Auction.find({
        status: 'scheduled',
        startTime: { $lte: now },
      });

      for (const auction of toActivate) {
        await Auction.findByIdAndUpdate(auction._id, { status: 'active' });
        try {
          const io = getIO();
          io.emit('auctionStarted', { auctionId: auction._id, title: auction.title });
        } catch (_) {}
        logger.info(`Auction activated: ${auction._id} "${auction.title}"`);
      }
    } catch (err) {
      logger.error(`Scheduler activate error: ${err.message}`);
    }
  }, POLL_INTERVAL);

  // End expired auctions
  setInterval(async () => {
    try {
      const now = new Date();
      const toEnd = await Auction.find({
        status: 'active',
        endTime: { $lte: now },
      }).populate('seller', '_id name email');

      for (const auction of toEnd) {
        const winningBid = await Bid.findOne({ auction: auction._id, isWinning: true })
          .populate('bidder', '_id name email');

        const updateData = { status: 'ended' };

        if (winningBid) {
          // Check reserve price
          const reserveMet = !auction.reservePrice || winningBid.amount >= auction.reservePrice;
          if (reserveMet) {
            updateData.winner = winningBid.bidder._id;
            updateData.winningBid = winningBid._id;
            updateData.status = 'ended';

            // Mark bid as won
            await Bid.findByIdAndUpdate(winningBid._id, { status: 'won' });

            // Notify winner
            await createNotification({
              recipient: winningBid.bidder._id,
              type: 'auction_won',
              title: '🎉 You won the auction!',
              message: `Congratulations! You won "${auction.title}" for $${winningBid.amount.toFixed(2)}. Please complete your payment.`,
              auction: auction._id,
            });

            // Notify seller
            await createNotification({
              recipient: auction.seller._id,
              type: 'auction_ended',
              title: 'Your auction has ended',
              message: `"${auction.title}" sold for $${winningBid.amount.toFixed(2)} to ${winningBid.bidder.name}.`,
              auction: auction._id,
            });

            // Notify all outbid users
            const outbidUsers = await Bid.find({
              auction: auction._id,
              status: 'outbid',
              bidder: { $ne: winningBid.bidder._id },
            }).distinct('bidder');

            for (const userId of outbidUsers) {
              await createNotification({
                recipient: userId,
                type: 'auction_ended',
                title: 'Auction ended',
                message: `"${auction.title}" has ended. You didn't win this time.`,
                auction: auction._id,
              });
            }
          }
        } else {
          // No bids — ended with no winner
          await createNotification({
            recipient: auction.seller._id,
            type: 'auction_ended',
            title: 'Auction ended — no bids',
            message: `"${auction.title}" ended without any bids.`,
            auction: auction._id,
          });
        }

        await Auction.findByIdAndUpdate(auction._id, updateData);

        // Broadcast auction end
        try {
          const io = getIO();
          io.to(`auction:${auction._id}`).emit('auctionEnded', {
            auctionId: auction._id,
            winner: winningBid?.bidder
              ? { id: winningBid.bidder._id, name: winningBid.bidder.name }
              : null,
            finalPrice: winningBid?.amount || auction.startingPrice,
          });
        } catch (_) {}

        logger.info(`Auction ended: ${auction._id} | winner: ${winningBid?.bidder?.name || 'none'}`);
      }
    } catch (err) {
      logger.error(`Scheduler end error: ${err.message}`);
    }
  }, POLL_INTERVAL);

  // Send "ending soon" notifications (5 minutes before end)
  setInterval(async () => {
    try {
      const fiveMinutesFromNow = new Date(Date.now() + 5 * 60 * 1000 + 30 * 1000);
      const fiveMinutesAgo = new Date(Date.now() + 5 * 60 * 1000 - 30 * 1000);

      const endingSoon = await Auction.find({
        status: 'active',
        endTime: { $gte: fiveMinutesAgo, $lte: fiveMinutesFromNow },
      });

      for (const auction of endingSoon) {
        // Notify watchers
        const watchers = await User.find({ watchlist: auction._id }).select('_id');
        for (const watcher of watchers) {
          await createNotification({
            recipient: watcher._id,
            type: 'watchlist_ending',
            title: '⏰ Auction ending soon!',
            message: `"${auction.title}" is ending in 5 minutes!`,
            auction: auction._id,
          });
          try {
            const io = getIO();
            io.to(`user:${watcher._id}`).emit('auctionEndingSoon', {
              auctionId: auction._id,
              title: auction.title,
            });
          } catch (_) {}
        }
      }
    } catch (err) {
      logger.error(`Scheduler ending-soon error: ${err.message}`);
    }
  }, POLL_INTERVAL);
};

module.exports = { scheduleAuctionJobs };
